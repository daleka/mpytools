// extension.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';
import { registerDependenciesCommand } from './dependenciesInstaller';
// NEW PART: Імпортуємо registerSaveProjectCommand
import { registerSaveProjectCommand } from './saveProject';

// Створюємо один глобальний Output Channel
export const mpyOutputChannel = vscode.window.createOutputChannel("MPyTools Log");

// Глобальні змінні для збереження версій
export let micropythonVersion: string | undefined = undefined;
export let micropythonBytecodeVersion: number | undefined = undefined;
export let micropythonArchitecture: string | undefined = undefined;
export let micropythonMsmallIntBits: number | undefined = undefined;

// Змінна, де ми зберігаємо останній вибраний порт.
let lastUsedPort: string = 'auto';
// Глобальна змінна для збереження обраного методу компіляції mpy-cross (0, 1, 2 або 3).
let selectedCompilationMethod: string | undefined = undefined;

export function activate(context: vscode.ExtensionContext): void {
  console.log('MPyTools розширення активоване.');

  // 1. Реєструємо команду встановлення залежностей
  registerDependenciesCommand(context, mpyOutputChannel);

  // 2. Запит на встановлення залежностей (при новій інсталяції)
  const packageJsonPath = context.asAbsolutePath('./package.json');
  const packageStats = fs.statSync(packageJsonPath);
  const currentInstallTime = packageStats.mtime.getTime();
  const storedInstallTime = context.globalState.get<number>('extensionInstallTime', 0);
  if (currentInstallTime > storedInstallTime) {
    context.globalState.update('extensionInstallTime', currentInstallTime);
    vscode.window.showInformationMessage(
      "MPyTools needs dependencies:\n- mpremote\n- mpy-cross\n- micropython-stdlib-stubs\nInstall them now?",
      "Yes",
      "No"
    ).then((choice) => {
      if (choice === "Yes") {
        vscode.commands.executeCommand('mpytools.installDependencies');
      } else {
        console.log("User chose not to install dependencies.");
      }
    });
  }

  // 3. Статус-бар для вибору порту
  let connectionStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 0);
  connectionStatusBarItem.text = '$(plug) Select Port';
  connectionStatusBarItem.tooltip = 'Click to select a MicroPython port';
  connectionStatusBarItem.color = 'red';
  connectionStatusBarItem.command = 'mpytools.selectPort';
  connectionStatusBarItem.show();
  context.subscriptions.push(connectionStatusBarItem);

  // Кнопка "Compile & Run" (прихована до вибору порту)
  let compileStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -1);
  compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
  compileStatusBarItem.tooltip = 'Натисніть, щоб скомпілювати та запустити проект';
  compileStatusBarItem.color = "lightblue";
  compileStatusBarItem.command = 'mpytools.compileAndRun';
  compileStatusBarItem.hide();
  context.subscriptions.push(compileStatusBarItem);

  // Кнопки Run, Stop, Reset
  let runStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  runStatusBarItem.text = '$(play) Run';
  runStatusBarItem.tooltip = 'Запустити активний файл';
  runStatusBarItem.command = 'mpytools.runActive';
  runStatusBarItem.hide();

  let stopStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  stopStatusBarItem.text = '$(debug-stop) Stop';
  stopStatusBarItem.tooltip = 'Зупинити виконання (Ctrl-C)';
  stopStatusBarItem.command = 'mpytools.stop';
  stopStatusBarItem.hide();

  let resetStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  resetStatusBarItem.text = '$(refresh) Reset';
  resetStatusBarItem.tooltip = 'Hard reset the device (mpremote connect <port> reset)';
  resetStatusBarItem.color = "#ff6666";
  resetStatusBarItem.command = 'mpytools.resetHard';
  resetStatusBarItem.hide();

  context.subscriptions.push(runStatusBarItem);
  context.subscriptions.push(stopStatusBarItem);
  context.subscriptions.push(resetStatusBarItem);

  // Команда "Run Active"
  vscode.commands.registerCommand('mpytools.runActive', async (): Promise<void> => {
    const terminalsToClose = vscode.window.terminals.filter(t =>
      t.name.startsWith("MPY") && t.name !== "MPY Compile&download"
    );
    terminalsToClose.forEach(t => t.dispose());

    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showWarningMessage("Немає активного файлу для запуску.");
      return;
    }
    const filePath = editor.document.uri.fsPath;

    mpyOutputChannel.appendLine("🔹 Run active file: " + filePath);

    let runTerminal = vscode.window.createTerminal('MPY Run');
    runTerminal.show();
    runTerminal.sendText(`mpremote run "${filePath}"`);
  });

  // Команда "Stop"
  vscode.commands.registerCommand('mpytools.stop', async (): Promise<void> => {
    const terminal = vscode.window.activeTerminal;
    if (terminal) {
      terminal.sendText("\x03", false); // Ctrl-C
      vscode.window.showInformationMessage("Stop: Ctrl-C надіслано. (Execution stopped)");
      mpyOutputChannel.appendLine("✅ Stop signal (Ctrl-C) sent.");
    } else {
      vscode.window.showWarningMessage("Немає активного терміналу.");
    }
  });

  // Команда "Reset Hard"
  vscode.commands.registerCommand('mpytools.resetHard', async (): Promise<void> => {
    try {
      const terminalsToClose = vscode.window.terminals.filter(t =>
        t.name.startsWith("MPY")
      );
      terminalsToClose.forEach(t => t.dispose());

      const usedPort = (lastUsedPort === 'auto') ? 'auto' : formatPort(lastUsedPort);
      mpyOutputChannel.appendLine(`🔹 Hard Reset on port "${lastUsedPort}"`);

      let resetTerminal = vscode.window.createTerminal('MPY Reset');
      resetTerminal.show();
      resetTerminal.sendText(`mpremote connect ${usedPort} reset`);

      vscode.window.showInformationMessage(`Device hard-reset requested on port "${lastUsedPort}"`);
      mpyOutputChannel.appendLine("✅ Hard reset command sent.");
    } catch (err: any) {
      vscode.window.showErrorMessage("Failed to reset (hard-reset) device: " + err);
      mpyOutputChannel.appendLine("❌ Error resetting device: " + err.message);
    }
  });

  // ======================
  // Команда "Select Port"
  // ======================
  let disposableSelectPort = vscode.commands.registerCommand('mpytools.selectPort', (): void => {
    exec('mpremote connect list', (error, stdout, stderr) => {
      if (error || stderr) {
        console.error("Error listing ports:", error || stderr);
        mpyOutputChannel.appendLine("❌ Error listing ports: " + (error?.message || stderr));
      }

      let availablePorts: string[] = [];
      if (!error && !stderr) {
        availablePorts = stdout
          .split('\n')
          .filter((line) => line.includes('COM') || line.includes('/dev/'))
          .map((line) => line.trim().split(' ')[0]);
      }
      if (!availablePorts.includes('auto')) {
        availablePorts.push('auto');
      }

      vscode.window.showQuickPick(availablePorts, {
        placeHolder: 'Select a port to use (current: ' + lastUsedPort + ')'
      }).then(async (selectedPort) => {
        if (!selectedPort) {
          return;
        }
        lastUsedPort = selectedPort;

        // Лог: Обраний порт
        mpyOutputChannel.appendLine(`🔹 Selected port: "${lastUsedPort}"`);

        // Показуємо "Connecting..." зі спінером
        connectionStatusBarItem.text = '$(sync~spin) MPY: Connecting...';
        connectionStatusBarItem.color = 'yellow';
        connectionStatusBarItem.tooltip = 'Connecting to the device...';

        // Закриваємо попередні MPY-термінали
        vscode.window.terminals
          .filter(t => t.name.startsWith("MPY"))
          .forEach(t => t.dispose());

        // 1-й DELAY (порт може бути ще зайнятий)
        await new Promise(resolve => setTimeout(resolve, 500));

        const usedPort = (lastUsedPort === 'auto') ? 'auto' : formatPort(lastUsedPort);

        mpyOutputChannel.show(true); // Показуємо лог для користувача
        mpyOutputChannel.appendLine(`🔹 Fetching device info (version, architecture, small-int bits)...`);
        mpyOutputChannel.appendLine(`🔹 Fetching MicroPython info via: mpremote connect ${usedPort} exec "import sys; ..."`);

        // 1) Отримуємо версію/байткод/архітектуру
        let fetchError: any = null;
        try {
          await fetchMicropythonVersionInfo(usedPort);
        } catch (err) {
          fetchError = err;
        }

        // 2) Форматуємо лог у потрібному порядку
        if (!fetchError) {
          // Виводимо "✅ Connected ..." одразу після рядків micropython*
          mpyOutputChannel.appendLine(`✅ Connected to port: "${lastUsedPort}"`);
          mpyOutputChannel.appendLine(`✅ Fetched device info successfully.`);
          mpyOutputChannel.appendLine(""); // Для розділення
        } else {
          mpyOutputChannel.appendLine(`❌ Could not fetch MicroPython info: ${fetchError}`);
          mpyOutputChannel.appendLine(""); 
        }

        // 3) Видаляємо теку "mpy"
        removeMpyFolder();

        // 4) 2-й DELAY (для безпеки перед відкриттям REPL)
        await new Promise(resolve => setTimeout(resolve, 300));

        // Тепер відкриваємо термінал з REPL
        let connectTerminal = vscode.window.createTerminal('MPY Session');
        connectTerminal.show();
        connectTerminal.sendText(
          `mpremote connect ${usedPort} exec "import os, gc; print(os.uname()); print('Free memory:', gc.mem_free())" + repl`
        );

        // Завершальний setTimeout для оновлення статус-бару
        setTimeout(() => {
          connectionStatusBarItem.text = `$(check) MPY: Using ${lastUsedPort}`;
          connectionStatusBarItem.color = 'green';
          connectionStatusBarItem.tooltip = 'Port selected';

          compileStatusBarItem.show();
          runStatusBarItem.show();
          stopStatusBarItem.show();
          resetStatusBarItem.show();
        }, 2000);
      });
    });
  });
  context.subscriptions.push(disposableSelectPort);

  // ======================
  // Команда "Compile & Run"
  // ======================
  let disposableCompileAndRun = vscode.commands.registerCommand('mpytools.compileAndRun', async (): Promise<void> => {
    let workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
      vscode.window.showErrorMessage('Не знайдено відкритий Workspace. (No workspace folder opened)');
      return;
    }

    // Якщо ще не вибраний рівень оптимізації, питаємо
    if (!selectedCompilationMethod) {
      const compilationOptions: vscode.QuickPickItem[] = [
        { label: 'mpy-cross optimization Level 0', description: 'Без оптимізації / No optimization' },
        { label: 'mpy-cross optimization Level 1', description: 'Базова оптимізація / Basic optimization' },
        { label: 'mpy-cross optimization Level 2', description: 'Середня оптимізація / Medium optimization' },
        { label: 'mpy-cross optimization Level 3', description: 'Максимальна оптимізація / Max optimization' }
      ];
      const result = await vscode.window.showQuickPick(compilationOptions, {
        placeHolder: 'Оберіть метод компіляції / Choose mpy-cross optimization level',
        canPickMany: false
      });
      if (!result) {
        vscode.window.showWarningMessage('Компіляцію скасовано / Compilation canceled: no method selected.');
        return;
      }
      const match = result.label.match(/Level (\d+)/);
      selectedCompilationMethod = match ? match[1] : '0';
    }

    const workspaceRoot = workspaceFolders[0].uri.fsPath;
    const srcPath = path.join(workspaceRoot, 'src');
    const mpyPath = path.join(workspaceRoot, 'mpy');

    // Закриваємо термінали MPY
    vscode.window.terminals.forEach((t) => {
      if (t.name.startsWith('MPY')) {
        t.dispose();
      }
    });

    // Невелика пауза
    await new Promise(resolve => setTimeout(resolve, 300));

    mpyOutputChannel.show(false);
    mpyOutputChannel.appendLine("🔹 Starting Compile & Run process...");
    mpyOutputChannel.appendLine(`   - Selected optimization level: O${selectedCompilationMethod}`);

    vscode.window.withProgress({
      location: vscode.ProgressLocation.Notification,
      title: 'MPyTools: Compile & Run',
      cancellable: false
    }, async (progress) => {
      try {
        progress.report({ message: 'Preparing compilation...' });
        mpyOutputChannel.appendLine("🔹 Preparing compilation...");

        if (!fs.existsSync(mpyPath)) {
          fs.mkdirSync(mpyPath);
          vscode.window.showInformationMessage(`Created directory (Створено теку): ${mpyPath}`);
          mpyOutputChannel.appendLine(`   ✅ Created directory: ${mpyPath}`);
        }

        let pyFiles = findPyFiles(srcPath, []);
        mpyOutputChannel.appendLine(`   🔹 Found ${pyFiles.length} .py files in "src"`);
        progress.report({ message: `Found ${pyFiles.length} .py files...` });

        compileStatusBarItem.color = 'red';
        compileStatusBarItem.text = '$(sync~spin) MPY: Please wait...';

        let compiledCount = 0;
        for (let i = 0; i < pyFiles.length; i++) {
          const pyFile = pyFiles[i];
          const shortName = path.relative(workspaceRoot, pyFile);

          if (needsRecompile(pyFile, srcPath, mpyPath)) {
            progress.report({ message: `Compiling: ${shortName}` });
            mpyOutputChannel.appendLine(`   🔹 Compiling: ${shortName}`);

            try {
              await compilePyFile(pyFile, srcPath, mpyPath);
              compiledCount++;
              mpyOutputChannel.appendLine(`      ✅ OK: ${shortName}`);
            } catch (err: any) {
              vscode.window.showWarningMessage(`Compilation error (Помилка компіляції): ${shortName}\n${err}`);
              mpyOutputChannel.appendLine(`      ❌ Compilation error: ${shortName} -> ${err.message}`);
            }
          } else {
            mpyOutputChannel.appendLine(`   🔹 Skipped (unchanged): ${shortName}`);
          }
        }

        mpyOutputChannel.appendLine(`   ✅ Compiled ${compiledCount} / ${pyFiles.length} py-files`);
        vscode.window.showInformationMessage(`Compiled (скомпільовано) ${compiledCount} out of (із) ${pyFiles.length}.`);

        // Копіюємо .mpy на пристрій
        let copyPath = mpyPath;
        if (os.platform() === 'win32') {
          copyPath += '\\.';
        } else {
          copyPath += '/.';
        }
        progress.report({ message: 'Copying files to device...' });
        mpyOutputChannel.appendLine("🔹 Copying compiled files to device...");

        const usedPort = lastUsedPort;
        const copyCmd = (usedPort === 'auto')
          ? `mpremote connect auto fs cp -r "${copyPath}" ":/"`
          : `mpremote connect ${formatPort(usedPort)} fs cp -r "${copyPath}" ":/"`;

        try {
          await execPromise(copyCmd);
          vscode.window.showInformationMessage('Copy complete (Копіювання завершено).');
          mpyOutputChannel.appendLine("   ✅ Copy complete.");
        } catch (err: any) {
          vscode.window.showErrorMessage(`Error copying files (Помилка копіювання): ${err}`);
          mpyOutputChannel.appendLine(`   ❌ Error copying files: ${err.message}`);
          compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
          compileStatusBarItem.color = 'lightblue';
          return;
        }

        // Відновлюємо вигляд кнопки
        compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
        compileStatusBarItem.color = 'lightblue';

        // Запускаємо main
        await new Promise(resolve => setTimeout(resolve, 500));
        let debugTerminal = vscode.window.createTerminal('MPY Debugging');
        debugTerminal.show();

        vscode.window.showInformationMessage('Launching main (Запуск main)...');
        mpyOutputChannel.appendLine("🔹 Launching main...");

        openTerminalAndRunMain((usedPort === 'auto') ? 'auto' : formatPort(usedPort), debugTerminal);

        progress.report({ message: 'Done.' });
        mpyOutputChannel.appendLine("✅ Compile & Run completed.\n");
      } catch (error: any) {
        vscode.window.showErrorMessage(`Compile & Run failed (Сталася помилка): ${error}`);
        mpyOutputChannel.appendLine(`❌ Compile & Run failed: ${error.message}`);
      }
    });
  });
  context.subscriptions.push(disposableCompileAndRun);

  // Реєструємо кнопку "Save Project" з окремого файлу
  registerSaveProjectCommand(context, mpyOutputChannel, execPromise);
}

/**
 * Витягує інформацію про версію MicroPython
 */
async function fetchMicropythonVersionInfo(port: string): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    const cmd = `mpremote connect ${port} exec "` +
      `import sys; ` +
      `print('MPYVER:', sys.implementation.version); ` +
      `print('MPYCODE:', sys.implementation._mpy); ` +
      `arch_val = (sys.implementation._mpy >> 10); print('MPYARCH:', arch_val); ` +
      `print('MAXSIZE:', sys.maxsize)` +
      `"`;
    mpyOutputChannel.appendLine(`🔹 Fetching MicroPython info via: ${cmd}`);

    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        mpyOutputChannel.appendLine("❌ Error running fetchMicropythonVersionInfo: " + error);
        reject(error);
        return;
      }
      if (stderr && stderr.trim()) {
        mpyOutputChannel.appendLine("❌ Stderr in fetchMicropythonVersionInfo: " + stderr.trim());
      }

      const archMap: Record<number, string> = {
        1: 'x86',
        2: 'x64',
        3: 'armv6',
        4: 'armv6m',
        5: 'armv7m',
        6: 'armv7em',
        7: 'armv7emsp',
        8: 'armv7emdp',
        9: 'xtensa',
        10: 'xtensawin',
        11: 'rv32imc'
      };

      function interpretMsmallIntBits(value: number): number | undefined {
        if (value === 2147483647) {
          return 31;
        }
        if (value === 9223372036854775807) {
          return 63;
        }
        if (value === 32767) {
          return 15;
        }
        return undefined;
      }

      const lines = stdout.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      for (const line of lines) {
        if (line.startsWith("MPYVER:")) {
          const versionPart = line.replace("MPYVER:", "").trim();
          micropythonVersion = versionPart;
          mpyOutputChannel.appendLine(`🔹 micropythonVersion = ${micropythonVersion || 'none'}`);
        } else if (line.startsWith("MPYCODE:")) {
          const codePart = line.replace("MPYCODE:", "").trim();
          micropythonBytecodeVersion = parseInt(codePart, 10);
          if (isNaN(micropythonBytecodeVersion)) {
            micropythonBytecodeVersion = undefined;
          }
          mpyOutputChannel.appendLine(`🔹 micropythonBytecodeVersion = ${micropythonBytecodeVersion ?? 'none'}`);
        } else if (line.startsWith("MPYARCH:")) {
          const archPart = line.replace("MPYARCH:", "").trim();
          const archNum = parseInt(archPart, 10);
          if (!isNaN(archNum) && archMap[archNum]) {
            micropythonArchitecture = archMap[archNum];
          } else {
            micropythonArchitecture = undefined;
          }
          mpyOutputChannel.appendLine(`🔹 micropythonArchitecture = ${micropythonArchitecture || 'none'}`);
        } else if (line.startsWith("MAXSIZE:")) {
          const maxsizePart = line.replace("MAXSIZE:", "").trim();
          const maxsizeNum = parseInt(maxsizePart, 10);
          if (!isNaN(maxsizeNum)) {
            micropythonMsmallIntBits = interpretMsmallIntBits(maxsizeNum);
          } else {
            micropythonMsmallIntBits = undefined;
          }
          mpyOutputChannel.appendLine(`🔹 micropythonMsmallIntBits = ${micropythonMsmallIntBits ?? 'none'}`);
        }
      }
      resolve();
    });
  });
}

/**
 * Виконує команду у shell і повертає Promise зі stdout або помилкою.
 */
export function execPromise(command: string): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }
      if (stderr && stderr.trim()) {
        reject(new Error(stderr));
        return;
      }
      resolve(stdout);
    });
  });
}

// ======================
// NEW: Функція видалення теки "mpy"
// ======================
function removeMpyFolder(): void {
  const workspaceFolders = vscode.workspace.workspaceFolders;
  if (!workspaceFolders || workspaceFolders.length === 0) {
    // Немає Workspace — нічого видаляти
    return;
  }
  const workspaceRoot = workspaceFolders[0].uri.fsPath;
  const mpyPath = path.join(workspaceRoot, 'mpy');

  if (!fs.existsSync(mpyPath)) {
    return; // Немає теки — нічого видаляти
  }

  mpyOutputChannel.appendLine("🔹 Removing 'mpy' folder from the project...");
  removeFolderRecursive(mpyPath);
  mpyOutputChannel.appendLine("✅ 'mpy' folder removed successfully.");
  mpyOutputChannel.appendLine(""); // Порожній рядок для розділення
}

/** Рекурсивно видаляє теку */
function removeFolderRecursive(dirPath: string): void {
  if (fs.existsSync(dirPath)) {
    fs.readdirSync(dirPath).forEach((file) => {
      const curPath = path.join(dirPath, file);
      if (fs.lstatSync(curPath).isDirectory()) {
        removeFolderRecursive(curPath);
      } else {
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(dirPath);
  }
}

/**
 * Інші допоміжні функції...
 */
function formatPort(port: string): string {
  const platform = os.platform();
  if (platform === 'win32') {
    return port;
  } else if (platform === 'linux' || platform === 'darwin') {
    return `/dev/${port}`;
  }
  return port;
}

function needsRecompile(pyFilePath: string, srcPath: string, mpyPath: string): boolean {
  const relative = path.relative(srcPath, pyFilePath);
  const outPath = path.join(mpyPath, relative.replace(/\.py$/, '.mpy'));
  if (!fs.existsSync(outPath)) {
    return true;
  }
  const pyStat = fs.statSync(pyFilePath);
  const mpyStat = fs.statSync(outPath);
  return (pyStat.mtime > mpyStat.mtime);
}

async function compilePyFile(
  pyFilePath: string,
  srcPath: string,
  mpyPath: string
): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    const relative = path.relative(srcPath, pyFilePath);
    const outPath = path.join(mpyPath, relative.replace(/\.py$/, '.mpy'));
    fs.mkdirSync(path.dirname(outPath), { recursive: true });

    const cmd = `mpy-cross -O${selectedCompilationMethod} "${pyFilePath}" -o "${outPath}"`;
    exec(cmd, (error, stdout, stderr) => {
      if (stdout && stdout.trim()) {
        console.log(`[mpy-cross stdout] ${stdout.trim()}`);
      }
      if (stderr && stderr.trim()) {
        console.error(`[mpy-cross stderr] ${stderr.trim()}`);
      }
      if (error) {
        reject(error);
      } else {
        resolve(outPath);
      }
    });
  });
}

function openTerminalAndRunMain(port: string, debugTerminal: vscode.Terminal): void {
  let connectCmd = '';
  if (port === 'auto') {
    connectCmd = 'mpremote connect auto exec "import main" + repl';
  } else {
    connectCmd = `mpremote connect ${port} exec "import main" + repl`;
  }
  debugTerminal.sendText(connectCmd);

  // Затримка перед викликом main.run(), якщо він існує
  setTimeout(() => {
    debugTerminal.sendText('main.run()');
  }, 2000);
}

function findPyFiles(rootDir: string, ignoreList: string[] = []): string[] {
  let results: string[] = [];
  function recurse(dir: string) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (let entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        recurse(fullPath);
      } else if (entry.isFile() && entry.name.endsWith('.py')) {
        if (!ignoreList.includes(entry.name)) {
          results.push(fullPath);
        }
      }
    }
  }
  if (fs.existsSync(rootDir)) {
    recurse(rootDir);
  }
  return results;
}

export function deactivate(): void {
  // Додаткові дії при деактивації, якщо потрібно.
}
