// compileAndRun.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';

/**
 * Функція реєструє кнопку та команду "mpytools.compileAndRun".
 * Уся логіка (запит оптимізації, компіляція, копіювання, запуск main) перенесена сюди з extension.ts.
 *
 * @param context               - контекст розширення
 * @param outputChannel         - канал виводу
 * @param execPromise           - функція для виконання shell-команд
 * @param getLastUsedPort       - функція-гетер для lastUsedPort
 * @param getSelectedMethod     - функція-гетер для selectedCompilationMethod
 * @param setSelectedMethod     - функція-сетер для selectedCompilationMethod
 * @param needsRecompile        - функція перевірки потреби перекомпіляції
 * @param compilePyFile         - функція компіляції одного .py у .mpy
 * @param findPyFiles           - функція пошуку .py в папці src
 * @param openTerminalAndRunMain - функція запуску main (mpremote connect ... + repl)
 * @param formatPort            - функція форматування порту
 * @param getMicropythonVersion - функція-гетер для micropythonVersion
 * @param getMicropythonBytecodeVersion - функція-гетер для micropythonBytecodeVersion
 * @param getMicropythonArchitecture - функція-гетер для micropythonArchitecture
 * @param getMicropythonMsmallIntBits - функція-гетер для micropythonMsmallIntBits
 *
 * @returns {vscode.StatusBarItem} Статус-бар елемент.
 */
export function registerCompileAndRunCommand(
  context: vscode.ExtensionContext,
  outputChannel: vscode.OutputChannel,
  execPromise: (cmd: string) => Promise<string>,
  getLastUsedPort: () => string,
  getSelectedMethod: () => string | undefined,
  setSelectedMethod: (val: string | undefined) => void,
  needsRecompile: (pyFilePath: string, srcPath: string, mpyPath: string) => boolean,
  compilePyFile: (
    pyFilePath: string,
    srcPath: string,
    mpyPath: string
  ) => Promise<string>,
  // Старий findPyFiles більше не використовуємо
  findPyFiles: (rootDir: string, ignoreList?: string[]) => string[],
  openTerminalAndRunMain: (port: string, debugTerminal: vscode.Terminal) => Promise<void>,
  formatPort: (port: string) => string,
  getMicropythonVersion: () => string | undefined,
  getMicropythonBytecodeVersion: () => number | undefined,
  getMicropythonArchitecture: () => string | undefined,
  getMicropythonMsmallIntBits: () => number | undefined
): vscode.StatusBarItem {
  // 1) Створюємо кнопку для "Compile & Run"
  let compileStatusBarItem = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Left,
    -1
  );
  compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
  compileStatusBarItem.tooltip = 'Click to compile and run the project';
  compileStatusBarItem.color = 'lightblue';
  compileStatusBarItem.command = 'mpytools.compileAndRun';
  compileStatusBarItem.hide();
  context.subscriptions.push(compileStatusBarItem);

  // 2) Реєструємо команду "mpytools.compileAndRun"
  let disposableCompileAndRun = vscode.commands.registerCommand('mpytools.compileAndRun', async () => {
    // 2.1 Перевірка незбережених файлів перед початком процесу
    const unsavedDocs = vscode.workspace.textDocuments.filter(doc => doc.isDirty);
    if (unsavedDocs.length > 0) {
      const choice = await vscode.window.showWarningMessage(
        'You have unsaved files. Do you want to save them before compiling? / У вас є незбережені файли. Бажаєте зберегти їх перед компіляцією?',
        'Yes / Так',
        'No / Ні'
      );
      if (choice === 'Yes / Так') {
        // Зберігаємо всі зміни
        await vscode.workspace.saveAll();
      }
      // Якщо вибір "No / Ні" або користувач закрив повідомлення – продовжуємо без збереження
    }

    // 2.2 Перевірка відкритого Workspace
    let workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
      vscode.window.showErrorMessage('No workspace folder opened.');
      return;
    }

    // 2.3 Запит рівня оптимізації (якщо він не обраний раніше)
    let currentMethod = getSelectedMethod();
    if (!currentMethod) {
      const compilationOptions: vscode.QuickPickItem[] = [
        { label: 'mpy-cross optimization Level 0', description: 'No optimization' },
        { label: 'mpy-cross optimization Level 1', description: 'Basic optimization' },
        { label: 'mpy-cross optimization Level 2', description: 'Medium optimization' },
        { label: 'mpy-cross optimization Level 3', description: 'Max optimization' }
      ];
      const result = await vscode.window.showQuickPick(compilationOptions, {
        placeHolder: 'Choose mpy-cross optimization level',
        canPickMany: false
      });
      if (!result) {
        vscode.window.showWarningMessage('Compilation canceled: no method selected.');
        return;
      }
      const match = result.label.match(/Level (\d+)/);
      const chosen = match ? match[1] : '0';
      setSelectedMethod(chosen);
      currentMethod = chosen;
    }

    // 2.4 Підготовчі змінні
    const workspaceRoot = workspaceFolders[0].uri.fsPath;
    const srcPath = path.join(workspaceRoot, 'src');
    const mpyPath = path.join(workspaceRoot, 'mpy');

    // Закриваємо термінали MPY
    vscode.window.terminals.forEach((t) => {
      if (t.name.startsWith('MPY')) {
        t.dispose();
      }
    });

    // Трішки почекаємо (візуальні дрібниці)
    await new Promise(resolve => setTimeout(resolve, 300));

    outputChannel.show(false);
    outputChannel.appendLine("🔹 Starting Compile & Run...");
    outputChannel.appendLine(`   - Selected optimization level: O${currentMethod}`);

    // 2.4.1 Формуємо і виводимо інформацію про mpy-cross (без вкладених бектиків)
    // Збираємо частини рядка у змінних, а потім об'єднуємо:
    const archFlag = getMicropythonArchitecture()
      ? `-march=${getMicropythonArchitecture()}`
      : '(no arch)';
    const smallIntFlag = getMicropythonMsmallIntBits()
      ? `-msmall-int-bits=${getMicropythonMsmallIntBits()}`
      : '(no small-int-bits)';
    const bytecodeFlag = (getMicropythonBytecodeVersion() !== undefined)
      ? `-b ${getMicropythonBytecodeVersion()}`
      : '-c 1.20';

    outputChannel.appendLine(
      '   - mpy-cross '
      + archFlag + ' '
      + smallIntFlag + ' '
      + `-O${currentMethod} `
      + bytecodeFlag
      + ' <path_to_file> -o <output_path>'
    );

    // 2.5 Основний процес з індикацією Progress
    vscode.window.withProgress({
      location: vscode.ProgressLocation.Notification,
      title: 'MPyTools: Compile & Run',
      cancellable: false
    }, async (progress) => {
      try {
        // 1) Створюємо теку mpy, якщо немає
        progress.report({ message: 'Preparing compilation...' });
        outputChannel.appendLine("🔹 Preparing compilation...");
        if (!fs.existsSync(mpyPath)) {
          fs.mkdirSync(mpyPath);
          vscode.window.showInformationMessage(`Created directory: ${mpyPath}`);
          outputChannel.appendLine(`   ✅ Created directory: ${mpyPath}`);
        }

        // 2) Знаходимо **всі** файли у директорії src (не лише .py)
        let allFiles: string[] = [];
        (function recurse(dir: string) {
          if (!fs.existsSync(dir)) {
            return;
          }
          const entries = fs.readdirSync(dir, { withFileTypes: true });
          for (let entry of entries) {
            const fullPath = path.join(dir, entry.name);
            if (entry.isDirectory()) {
              recurse(fullPath);
            } else {
              allFiles.push(fullPath);
            }
          }
        })(srcPath);

        outputChannel.appendLine(`   🔹 Found ${allFiles.length} total files in "src" (including non-PY).`);

        // Статус-бар (крутиться)
        compileStatusBarItem.color = 'red';
        compileStatusBarItem.text = '$(sync~spin) MPY: Please wait...';

        let compiledCount = 0;
        let copiedNonPyCount = 0;

        // 3) Проходимось по кожному знайденому файлу
        for (let i = 0; i < allFiles.length; i++) {
          const filePath = allFiles[i];
          const shortName = path.relative(workspaceRoot, filePath);
          const extName = path.extname(filePath).toLowerCase(); // .py, .html тощо

          // Визначимо шлях, куди має зберегтися файл у папці mpy
          const relativeFromSrc = path.relative(srcPath, filePath);
          const outPath = path.join(mpyPath, relativeFromSrc);

          // Якщо це .py => компілюємо (за потреби)
          if (extName === '.py') {
            if (needsRecompile(filePath, srcPath, mpyPath)) {
              progress.report({ message: `Compiling: ${shortName}` });
              outputChannel.appendLine(`   🔹 Compiling: ${shortName}`);
              try {
                await compilePyFile(filePath, srcPath, mpyPath);
                compiledCount++;
                outputChannel.appendLine(`      ✅ OK: ${shortName}`);
              } catch (err: any) {
                vscode.window.showWarningMessage(`Compilation error: ${shortName}\n${err}`);
                outputChannel.appendLine(`      ❌ Compilation error: ${shortName} -> ${err.message}`);
              }
              outputChannel.appendLine("");
            } else {
              outputChannel.appendLine(`   🔹 Skipped (unchanged .py): ${shortName}`);
              outputChannel.appendLine("");
            }
          } else {
            // Якщо це інший файл (.html, .css тощо) => просто копіюємо (з перевіркою)
            if (!fs.existsSync(outPath)) {
              copyWithMkDir(filePath, outPath);
              copiedNonPyCount++;
              outputChannel.appendLine(`   🔹 Copied (new): ${shortName}`);
              outputChannel.appendLine(
                `      ⚠️ Found ${extName} file. For faster debugging, consider packaging or converting assets to .py if possible.`
              );
            } else {
              if (!areFilesIdentical(filePath, outPath)) {
                copyWithMkDir(filePath, outPath);
                copiedNonPyCount++;
                outputChannel.appendLine(`   🔹 Replaced (updated): ${shortName}`);
                outputChannel.appendLine(
                  `      ⚠️ Found ${extName} file. For faster debugging, consider packaging or converting assets to .py if possible.`
                );
              } else {
                outputChannel.appendLine(`   🔹 Skipped (identical ${extName}): ${shortName}`);
              }
            }
            outputChannel.appendLine("");
          }
        }

        outputChannel.appendLine(`   ✅ Compiled ${compiledCount} .py files; Copied ${copiedNonPyCount} non-py files.`);
        vscode.window.showInformationMessage(
          `Compiled ${compiledCount} .py files; copied ${copiedNonPyCount} other files.`
        );

        // 5) Копіюємо теку mpy на пристрій
        outputChannel.appendLine("🔹 Copying compiled files to device...");
        const usedPort = getLastUsedPort();
        const finalPort = (usedPort === 'auto') ? 'auto' : formatPort(usedPort);
        const copyPath = os.platform() === 'win32' ? `${mpyPath}\\.` : `${mpyPath}/.`;
        const copyCmd = (finalPort === 'auto')
          ? `mpremote connect auto fs cp -r "${copyPath}" ":/"`
          : `mpremote connect ${finalPort} fs cp -r "${copyPath}" ":/"`;

        try {
          await execPromise(copyCmd);
          vscode.window.showInformationMessage('Copy complete.');
          outputChannel.appendLine("   ✅ Copy complete.");
        } catch (err: any) {
          vscode.window.showErrorMessage(`Error copying files: ${err}`);
          outputChannel.appendLine(`   ❌ Error copying files: ${err.message}`);
          compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
          compileStatusBarItem.color = 'lightblue';
          return;
        }

        // 6) Оцінимо розмір тек
        const folderSizeKB = getFolderSizeKB(mpyPath);
        outputChannel.appendLine(`🔹 Total size of 'mpy' folder: ${folderSizeKB.toFixed(2)} KB`);
        outputChannel.appendLine("🔹 Launching main...");

        // 7) Запускаємо main
        function delay(ms: number): Promise<void> {
          return new Promise(resolve => setTimeout(resolve, ms));
        }

        // Повідомляємо про завершення та даємо 2 секунди на перегляд логів
        outputChannel.appendLine("✅ Compile & Run completed.");
        await delay(2000);

        // 8) Повертаємо кнопку до нормального стану
        compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
        compileStatusBarItem.color = 'lightblue';

        // Тільки після затримки активуємо термінал
        let debugTerminal = vscode.window.createTerminal('MPY Debugging');
        debugTerminal.show();
        await openTerminalAndRunMain(finalPort, debugTerminal);

        // 8) Повертаємо кнопку до нормального стану
        compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
        compileStatusBarItem.color = 'lightblue';
              
      } catch (error: any) {
        vscode.window.showErrorMessage(`Compile & Run failed: ${error}`);
        outputChannel.appendLine(`❌ Compile & Run failed: ${error.message}`);
      }
    });
  });

  context.subscriptions.push(disposableCompileAndRun);
  return compileStatusBarItem;
}

/**
 * Копіює файл із `srcFile` у `destFile`, створюючи проміжні директорії за потреби.
 */
function copyWithMkDir(srcFile: string, destFile: string) {
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  fs.copyFileSync(srcFile, destFile);
}

/**
 * Перевіряє, чи два файли ідентичні (швидка перевірка розміру + детальне порівняння, якщо треба).
 */
function areFilesIdentical(fileA: string, fileB: string): boolean {
  try {
    const statA = fs.statSync(fileA);
    const statB = fs.statSync(fileB);
    if (statA.size !== statB.size) {
      return false; // різні розміри => точно різні
    }
    const bufA = fs.readFileSync(fileA);
    const bufB = fs.readFileSync(fileB);
    return bufA.equals(bufB);
  } catch {
    return false;
  }
}

/**
 * Підраховує розмір тек у KB (рекурсивно).
 */
function getFolderSizeKB(dirPath: string): number {
  let totalSize = 0;
  function recurse(folder: string) {
    if (!fs.existsSync(folder)) {
      return;
    }
    const files = fs.readdirSync(folder);
    for (const file of files) {
      const fullPath = path.join(folder, file);
      const stats = fs.statSync(fullPath);
      if (stats.isDirectory()) {
        recurse(fullPath);
      } else {
        totalSize += stats.size;
      }
    }
  }
  recurse(dirPath);
  return totalSize / 1024;
}
