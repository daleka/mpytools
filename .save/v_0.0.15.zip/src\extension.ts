
// extension.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';
import { registerDependenciesCommand } from './dependenciesInstaller';
import { registerSaveProjectCommand } from './saveProject';
import { registerCompileAndRunCommand } from './compileAndRun';

// Глобальний Output Channel
export const mpyOutputChannel = vscode.window.createOutputChannel("MPyTools Log");

// Глобальні змінні збереження версій
export let micropythonVersion: string | undefined = undefined;
export let micropythonBytecodeVersion: number | undefined = undefined;
export let micropythonArchitecture: string | undefined = undefined;
export let micropythonMsmallIntBits: number | undefined = undefined;

// (NEW!) Додаємо для sysname/release
export let micropythonSysName: string | undefined = undefined;
export let micropythonRelease: string | undefined = undefined;

// Останній вибраний порт
let lastUsedPort: string = 'auto';
// Обраний метод компіляції
let selectedCompilationMethod: string | undefined = undefined;

export function activate(context: vscode.ExtensionContext): void {
  console.log('MPyTools розширення активоване.');

  // 1. Команда встановлення залежностей
  registerDependenciesCommand(context, mpyOutputChannel);

  // 1.5 Команда збереження проєкту
  registerSaveProjectCommand(context, mpyOutputChannel, execPromise);

  // 2. Запит на встановлення залежностей (нове встановлення)
  const packageJsonPath = context.asAbsolutePath('./package.json');
  const packageStats = fs.statSync(packageJsonPath);
  const currentInstallTime = packageStats.mtime.getTime();
  const storedInstallTime = context.globalState.get<number>('extensionInstallTime', 0);
  if (currentInstallTime > storedInstallTime) {
    context.globalState.update('extensionInstallTime', currentInstallTime);
    vscode.window.showInformationMessage(
      "MPyTools needs dependencies:\n- mpremote\n- mpy-cross\n- micropython-stdlib-stubs\nInstall them now?",
      "Yes",
      "No"
    ).then((choice) => {
      if (choice === "Yes") {
        vscode.commands.executeCommand('mpytools.installDependencies');
      } else {
        console.log("User chose not to install dependencies.");
      }
    });
  }

  // 3. Статус-бар для вибору порту
  let connectionStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 0);
  connectionStatusBarItem.text = '$(plug) Select Port';
  connectionStatusBarItem.tooltip = 'Click to select a MicroPython port';
  connectionStatusBarItem.color = 'red';
  connectionStatusBarItem.command = 'mpytools.selectPort';
  connectionStatusBarItem.show();
  context.subscriptions.push(connectionStatusBarItem);

  // Кнопка Run
  let runStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  runStatusBarItem.text = '$(play) Run';
  runStatusBarItem.tooltip = 'Запустити активний файл';
  runStatusBarItem.command = 'mpytools.runActive';
  runStatusBarItem.hide();
  context.subscriptions.push(runStatusBarItem);

  // Кнопка Stop
  let stopStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  stopStatusBarItem.text = '$(debug-stop) Stop';
  stopStatusBarItem.tooltip = 'Зупинити виконання (Ctrl-C)';
  stopStatusBarItem.command = 'mpytools.stop';
  stopStatusBarItem.hide();
  context.subscriptions.push(stopStatusBarItem);

  // Кнопка Reset
  let resetStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  resetStatusBarItem.text = '$(refresh) Reset';
  resetStatusBarItem.tooltip = 'Hard reset device';
  resetStatusBarItem.color = "#ff6666";
  resetStatusBarItem.command = 'mpytools.resetHard';
  resetStatusBarItem.hide();
  context.subscriptions.push(resetStatusBarItem);

  // Команда "Run Active"
  vscode.commands.registerCommand('mpytools.runActive', async (): Promise<void> => {
    const terminalsToClose = vscode.window.terminals.filter(t =>
      t.name.startsWith("MPY") && t.name !== "MPY Compile&download"
    );
    terminalsToClose.forEach(t => t.dispose());

    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showWarningMessage("Немає активного файлу для запуску.");
      return;
    }
    const filePath = editor.document.uri.fsPath;

    mpyOutputChannel.appendLine("🔹 Run active file: " + filePath);

    let runTerminal = vscode.window.createTerminal('MPY Run');
    runTerminal.show();
    runTerminal.sendText(`mpremote run "${filePath}"`);
  });

  // Команда "Stop"
  vscode.commands.registerCommand('mpytools.stop', async (): Promise<void> => {
    const terminal = vscode.window.activeTerminal;
    if (terminal) {
      terminal.sendText("\x03", false); // Ctrl-C
      vscode.window.showInformationMessage("Stop: Ctrl-C надіслано. (Execution stopped)");
      mpyOutputChannel.appendLine("✅ Stop signal (Ctrl-C) sent.");
    } else {
      vscode.window.showWarningMessage("Немає активного терміналу.");
    }
  });

  // Команда "Reset Hard"
  vscode.commands.registerCommand('mpytools.resetHard', async (): Promise<void> => {
    try {
      const terminalsToClose = vscode.window.terminals.filter(t =>
        t.name.startsWith("MPY")
      );
      terminalsToClose.forEach(t => t.dispose());

      const usedPort = (lastUsedPort === 'auto') ? 'auto' : formatPort(lastUsedPort);
      mpyOutputChannel.appendLine(`🔹 Hard Reset on port "${lastUsedPort}"`);

      let resetTerminal = vscode.window.createTerminal('MPY Reset');
      resetTerminal.show();
      resetTerminal.sendText(`mpremote connect ${usedPort} reset`);

      vscode.window.showInformationMessage(`Device hard-reset requested on port "${lastUsedPort}"`);
      mpyOutputChannel.appendLine("✅ Hard reset command sent.");
    } catch (err: any) {
      vscode.window.showErrorMessage("Failed to reset (hard-reset) device: " + err);
      mpyOutputChannel.appendLine("❌ Error resetting device: " + err.message);
    }
  });

// Команда "Select Port"
let disposableSelectPort = vscode.commands.registerCommand('mpytools.selectPort', async (): Promise<void> => {
  // 1) Закриваємо всі активні термінали MPY
  vscode.window.terminals
    .filter(t => t.name.startsWith("MPY"))
    .forEach(t => t.dispose());

  // 2) Робимо вікно виводу активним
  mpyOutputChannel.show(true);

  // 3) Затримка 300 мс
  await new Promise(resolve => setTimeout(resolve, 300));
  
  connectionStatusBarItem.text = '$(sync~spin) Scanning ports...';
  connectionStatusBarItem.color = 'yellow';
  connectionStatusBarItem.tooltip = 'Scanning available ports...';

  exec('mpremote connect list', async (error, stdout, stderr) => {
    if (error || stderr) {
      console.error("Error listing ports:", error || stderr);
      mpyOutputChannel.appendLine("❌ Error listing ports: " + (error?.message || stderr));
    }

    let availablePorts: string[] = [];
    if (!error && !stderr) {
      availablePorts = stdout
        .split('\n')
        .filter((line) => line.includes('COM') || line.includes('/dev/'))
        .map((line) => line.trim().split(' ')[0])
        .filter(Boolean);
    }

    // Додаємо 'auto' (якщо немає)
    if (!availablePorts.includes('auto')) {
      availablePorts.push('auto');
    }

    mpyOutputChannel.appendLine("🔹 Probing each port for device info...");

    // Готуємо масив для QuickPick
    interface PortQuickPickItem {
      label: string;
      rawPort: string;
    }
    const quickPickItems: PortQuickPickItem[] = [];

    // 1) Перевіряємо кожен порт (окрім 'auto')
    for (const port of availablePorts) {
      if (port === 'auto') {
        continue;
      }

      try {
        const cmd = `mpremote connect ${port} exec "import os; print(os.uname())"`;
        mpyOutputChannel.appendLine(`   Checking port: ${port} -> ${cmd}`);

        const deviceInfo = await execPromise(cmd);
        let sysMatch = deviceInfo.match(/sysname='([^']+)'/);
        let relMatch = deviceInfo.match(/release='([^']+)'/);
        let machineMatch = deviceInfo.match(/machine='([^']+)'/);

        let sys = sysMatch ? sysMatch[1] : '';
        let rel = relMatch ? relMatch[1] : '';
        let mach = machineMatch ? machineMatch[1] : '';

        if (sys && rel && mach) {
          quickPickItems.push({
            label: `${port} (${sys} ${rel} ${mach})`,
            rawPort: port
          });
        } else {
          quickPickItems.push({
            label: `${port} (Micropython detected, but can't parse uname)`,
            rawPort: port
          });
        }

      } catch (err: any) {
        mpyOutputChannel.appendLine(`   ❌ Could not read device info on port ${port}: ${err.message}`);
        quickPickItems.push({
          label: `${port} (Failed to access...(it may be in use by another program))`,
          rawPort: port
        });
      }
    }

    // 2) Додаємо пункт AUTO
    quickPickItems.push({
      label: `AUTO (Automatic connection to the first available device)`,
      rawPort: 'auto'
    });

    // Відкриваємо QuickPick
    vscode.window.showQuickPick(quickPickItems, {
      placeHolder: `Select a port to use (current: ${lastUsedPort})`
    }).then(async (selectedItem) => {
      // Якщо користувач скасував вибір (натиснув Esc)
      if (!selectedItem) {
        // NEW: Повертаємо початковий вигляд кнопки
        connectionStatusBarItem.text = '$(plug) Select Port';
        connectionStatusBarItem.color = 'red';
        connectionStatusBarItem.tooltip = 'Click to select a MicroPython port';
        return;
      }

      // Якщо порт обрано
      lastUsedPort = selectedItem.rawPort;
      mpyOutputChannel.appendLine(`🔹 Selected port: "${lastUsedPort}"`);

      // --- Тут іде вже існуючий код ---
      // "Connecting..." зі спінером
      connectionStatusBarItem.text = '$(sync~spin) MPY: Connecting...';
      connectionStatusBarItem.color = 'yellow';
      connectionStatusBarItem.tooltip = 'Connecting to the device...';

      // Закриваємо попередні MPY-термінали
      vscode.window.terminals
        .filter(t => t.name.startsWith("MPY"))
        .forEach(t => t.dispose());

      // 1-й DELAY (0.5 c)
      await new Promise(resolve => setTimeout(resolve, 500));

      const usedPort = (lastUsedPort === 'auto') ? 'auto' : formatPort(lastUsedPort);

      mpyOutputChannel.show(true);
      mpyOutputChannel.appendLine(`🔹 Fetching device info (version, architecture, small-int bits)...`);
      mpyOutputChannel.appendLine(`🔹 Fetching MicroPython info via: mpremote connect ${usedPort} exec "import sys; ..."`);

      let fetchError: any = null;
      try {
        await fetchMicropythonVersionInfo(usedPort);
      } catch (err) {
        fetchError = err;
      }

      if (!fetchError) {
        mpyOutputChannel.appendLine(`✅ Connected to port: "${lastUsedPort}"`);
        mpyOutputChannel.appendLine(`✅ Fetched device info successfully.`);
        mpyOutputChannel.appendLine("");

        // Показуємо кнопки (Run, Stop, Reset...)
        compileStatusBarItem.show();
        runStatusBarItem.show();
        stopStatusBarItem.show();
        resetStatusBarItem.show();

        // Встановлюємо зелений колір + короткий опис
        connectionStatusBarItem.text = `✅ ${micropythonSysName ?? '???'} ${micropythonRelease ?? ''} ${lastUsedPort}`;
        connectionStatusBarItem.color = 'green';
        connectionStatusBarItem.tooltip = 'Port selected';

      } else {
        mpyOutputChannel.appendLine(`❌ Could not fetch MicroPython info: ${fetchError}`);
        mpyOutputChannel.appendLine("");
        // (За бажанням можна повертати колір у червоний тощо)
      }

      removeMpyFolder();
      await new Promise(resolve => setTimeout(resolve, 300));

      // Створюємо термінал, але поки НЕ викликаємо show()
      let connectTerminal = vscode.window.createTerminal('MPY Session');
      connectTerminal.sendText(
        `mpremote connect ${usedPort} exec "import os, gc; print(os.uname()); print('Free memory:', gc.mem_free())" + repl`
      );

      setTimeout(() => {
        connectTerminal.show();
      }, 1500);
    });
  });
});
context.subscriptions.push(disposableSelectPort);

  // ...
 // end of activate

  // ===============================
  // Реєструємо "Compile & Run"
  // ===============================
  const compileStatusBarItem = registerCompileAndRunCommand(
    context,
    mpyOutputChannel,
    execPromise,
    () => lastUsedPort,
    () => selectedCompilationMethod,
    (val: string | undefined) => { selectedCompilationMethod = val; },
    needsRecompile,
    compilePyFile,
    findPyFiles,
    openTerminalAndRunMain,
    formatPort,
    () => micropythonVersion,         
    () => micropythonBytecodeVersion, 
    () => micropythonArchitecture,    
    () => micropythonMsmallIntBits
  );
} // Завершення функції activate

/**
 * Витягує інформацію про версію MicroPython, а також sysname/release
 */
async function fetchMicropythonVersionInfo(port: string): Promise<void> {
  // Один-єдиний виклик mpremote для sys.implementation + os.uname()
  const cmd = `mpremote connect ${port} exec "` +
    `import sys, os; ` +
    `print('MPYVER:', sys.implementation.version); ` +
    `print('MPYCODE:', sys.implementation._mpy); ` +
    `arch_val = (sys.implementation._mpy >> 10); print('MPYARCH:', arch_val); ` +
    `print('MAXSIZE:', sys.maxsize); ` +
    `u=os.uname(); ` +
    `print('SYSNAME:', u.sysname); ` +
    `print('RELEASE:', u.release); ` +
    `"`;

  mpyOutputChannel.appendLine(`🔹 Fetching MicroPython info via: ${cmd}`);

  return new Promise<void>((resolve, reject) => {
    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        mpyOutputChannel.appendLine("❌ Error running fetchMicropythonVersionInfo: " + error);
        return reject(error);
      }
      if (stderr && stderr.trim()) {
        mpyOutputChannel.appendLine("❌ Stderr in fetchMicropythonVersionInfo: " + stderr.trim());
      }

      const archMap: Record<number, string> = {
        1: 'x86',
        2: 'x64',
        3: 'armv6',
        4: 'armv6m',
        5: 'armv7m',
        6: 'armv7em',
        7: 'armv7emsp',
        8: 'armv7emdp',
        9: 'xtensa',
        10: 'xtensawin',
        11: 'rv32imc'
      };

      function interpretMsmallIntBits(value: number): number | undefined {
        if (value === 2147483647) {
          return 31;
        }
        if (value === 9223372036854775807) {
          return 63;
        }
        if (value === 32767) {
          return 15;
        }
        return undefined;
      }

      let sysVal = 'unknown';
      let relVal = 'unknown';

      const lines = stdout.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      for (const line of lines) {
        if (line.startsWith("MPYVER:")) {
          micropythonVersion = line.replace("MPYVER:", "").trim();
          mpyOutputChannel.appendLine(`🔹 micropythonVersion = ${micropythonVersion || 'none'}`);
        } else if (line.startsWith("MPYCODE:")) {
          let codeNum = parseInt(line.replace("MPYCODE:", "").trim(), 10);
          if (isNaN(codeNum)) { codeNum = -1; }
          micropythonBytecodeVersion = codeNum >= 0 ? codeNum : undefined;
          mpyOutputChannel.appendLine(`🔹 micropythonBytecodeVersion = ${micropythonBytecodeVersion ?? 'none'}`);
        } else if (line.startsWith("MPYARCH:")) {
          const archNum = parseInt(line.replace("MPYARCH:", "").trim(), 10);
          micropythonArchitecture = archMap[archNum] ?? undefined;
          mpyOutputChannel.appendLine(`🔹 micropythonArchitecture = ${micropythonArchitecture || 'none'}`);
        } else if (line.startsWith("MAXSIZE:")) {
          const maxsizeNum = parseInt(line.replace("MAXSIZE:", "").trim(), 10);
          micropythonMsmallIntBits = !isNaN(maxsizeNum) ? interpretMsmallIntBits(maxsizeNum) : undefined;
          mpyOutputChannel.appendLine(`🔹 micropythonMsmallIntBits = ${micropythonMsmallIntBits ?? 'none'}`);
        } else if (line.startsWith("SYSNAME:")) {
          sysVal = line.replace("SYSNAME:", "").trim();
          mpyOutputChannel.appendLine(`🔹 sysname = ${sysVal}`);
        } else if (line.startsWith("RELEASE:")) {
          relVal = line.replace("RELEASE:", "").trim();
          mpyOutputChannel.appendLine(`🔹 release = ${relVal}`);
        }
      }

      // (NEW!) Зберігаємо sysname/release у глобальні змінні
      micropythonSysName = sysVal;
      micropythonRelease = relVal;

      resolve();
    });
  });
}

/**
 * Виконує команду у shell і повертає Promise зі stdout або помилкою
 */
export function execPromise(command: string): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }
      if (stderr && stderr.trim()) {
        reject(new Error(stderr));
        return;
      }
      resolve(stdout);
    });
  });
}


/**
 * Функція для видалення теку "mpy"
 */
function removeMpyFolder(): void {
  const workspaceFolders = vscode.workspace.workspaceFolders;
  if (!workspaceFolders || workspaceFolders.length === 0) {
    return;
  }
  const workspaceRoot = workspaceFolders[0].uri.fsPath;
  const mpyPath = path.join(workspaceRoot, 'mpy');

  if (!fs.existsSync(mpyPath)) {
    return;
  }

  mpyOutputChannel.appendLine("🔹 Removing 'mpy' folder from the project...");
  removeFolderRecursive(mpyPath);
  mpyOutputChannel.appendLine("✅ 'mpy' folder removed successfully.");
  mpyOutputChannel.appendLine("");
}

/** Рекурсивно видаляє теку */
function removeFolderRecursive(dirPath: string): void {
  if (fs.existsSync(dirPath)) {
    fs.readdirSync(dirPath).forEach((file) => {
      const curPath = path.join(dirPath, file);
      if (fs.lstatSync(curPath).isDirectory()) {
        removeFolderRecursive(curPath);
      } else {
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(dirPath);
  }
}

/**
 * Форматує порт залежно від платформи: COM4 -> COM4, /dev/... -> /dev/...
 */
function formatPort(port: string): string {
  const platform = os.platform();
  if (platform === 'win32') {
    return port;
  } else if (platform === 'linux' || platform === 'darwin') {
    return `/dev/${port}`;
  }
  return port;
}

/**
 * Перевіряє, чи потрібна перекомпіляція файлу .py -> .mpy
 */
function needsRecompile(pyFilePath: string, srcPath: string, mpyPath: string): boolean {
  const relative = path.relative(srcPath, pyFilePath);
  const outPath = path.join(mpyPath, relative.replace(/\.py$/, '.mpy'));
  if (!fs.existsSync(outPath)) {
    return true;
  }
  const pyStat = fs.statSync(pyFilePath);
  const mpyStat = fs.statSync(outPath);
  return (pyStat.mtime > mpyStat.mtime);
}

/**
 * Допоміжні функції для роботи з версіями
 */
function parseVersion(version: string): number[] {
  const nums = version.match(/\d+/g);
  if (!nums) {
    return [];
  }
  return nums.slice(0, 3).map(Number);
}

function compareVersions(v1: number[], v2: number[]): number {
  const len = Math.max(v1.length, v2.length);
  for (let i = 0; i < len; i++) {
    const a = v1[i] || 0;
    const b = v2[i] || 0;
    if (a > b) {
      return 1;
    }
    if (a < b) {
      return -1;
    }
  }
  return 0;
}

/**
 * Визначає підтримувану версію байткоду для заданої версії MicroPython.
 * Якщо версія не задана або не може бути спарсена – повертає undefined.
 *
 * Логіка:
 * - Версії від 1.12.0 (включно) до 1.19.0 (не включно) повертають 5.
 * - Версії від 1.19.0 (включно) до 1.20.0 (не включно) повертають 6.
 * - Версії від 1.20.0 (включно) до 1.23.0 (не включно) повертають 6.1.
 * - Версії ≥ 1.23.0 повертають 6.3.
 */
function getSupportedBytecodeVersion(micropythonVersion: string | undefined): number | undefined {
  if (!micropythonVersion) {
    return undefined;
  }
  const ver = parseVersion(micropythonVersion);
  if (ver.length < 3) {
    return undefined;
  }
  const v112 = [1, 12, 0];
  const v119 = [1, 19, 0];
  const v120 = [1, 20, 0];
  const v123 = [1, 23, 0];

  if (compareVersions(ver, v112) >= 0 && compareVersions(ver, v119) < 0) {
    return 5;
  } else if (compareVersions(ver, v119) >= 0 && compareVersions(ver, v120) < 0) {
    return 6;
  } else if (compareVersions(ver, v120) >= 0 && compareVersions(ver, v123) < 0) {
    return 6.1;
  } else if (compareVersions(ver, v123) >= 0) {
    return 6.3;
  }
  return undefined;
}

async function compilePyFile(
  pyFilePath: string,
  srcPath: string,
  mpyPath: string
): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    const relative = path.relative(srcPath, pyFilePath);
    const outPath = path.join(mpyPath, relative.replace(/\.py$/, '.mpy'));
    fs.mkdirSync(path.dirname(outPath), { recursive: true });

    // Формування команди з умовним включенням параметрів
    const archFlag = micropythonArchitecture ? `-march=${micropythonArchitecture}` : '';
    const smallIntFlag = micropythonMsmallIntBits ? `-msmall-int-bits=${micropythonMsmallIntBits}` : '';
    const optimizationFlag = selectedCompilationMethod ? `-O${selectedCompilationMethod}` : '';
    const bytecodeVersion = getSupportedBytecodeVersion(micropythonVersion);
    let versionFlag = '';
    if (bytecodeVersion !== undefined) {
      versionFlag = `-b ${bytecodeVersion}`;
    } else {
      mpyOutputChannel.appendLine("⚠️ Warning: Bytecode not supported for this version of MicroPython. Skipping -b flag.");
    }

    const cmd = `mpy-cross ${archFlag} ${smallIntFlag} ${optimizationFlag} ${versionFlag} "${pyFilePath}" -o "${outPath}"`
      .replace(/\s+/g, ' ')
      .trim();

    mpyOutputChannel.appendLine(`🔹 Running mpy-cross command: ${cmd}`);
    if (!micropythonArchitecture) {
      mpyOutputChannel.appendLine("⚠️ Warning: micropythonArchitecture not obtained. Omitting -march flag.");
    }
    if (!micropythonMsmallIntBits) {
      mpyOutputChannel.appendLine("⚠️ Warning: micropythonMsmallIntBits not obtained. Omitting -msmall-int-bits flag.");
    }
    // Друге виведення попередження щодо байт-коду видалено

    exec(cmd, (error, stdout, stderr) => {
      if (stdout && stdout.trim()) {
        console.log(`[mpy-cross stdout] ${stdout.trim()}`);
      }
      if (stderr && stderr.trim()) {
        console.error(`[mpy-cross stderr] ${stderr.trim()}`);
      }
      if (error) {
        reject(error);
      } else {
        resolve(outPath);
      }
    });
  });
}

/**
 * Відкриває термінал і виконує mpremote connect <port> exec "import main" + repl,
 * а потім через 2 секунди викликає main.run().
 */
async function openTerminalAndRunMain(port: string, debugTerminal: vscode.Terminal): Promise<void> {
  let connectCmd = '';
  if (port === 'auto') {
    connectCmd = 'mpremote connect auto exec "import main" + repl';
  } else {
    connectCmd = `mpremote connect ${port} exec "import main" + repl`;
  }
  debugTerminal.sendText(connectCmd);
  await delay(2000);
  debugTerminal.sendText('main.run()');
}

/**
 * Допоміжна функція затримки.
 */
function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Пошук .py файлів у директорії
 */
function findPyFiles(rootDir: string, ignoreList: string[] = []): string[] {
  let results: string[] = [];
  function recurse(dir: string) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (let entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        recurse(fullPath);
      } else if (entry.isFile() && entry.name.endsWith('.py')) {
        if (!ignoreList.includes(entry.name)) {
          results.push(fullPath);
        }
      }
    }
  }
  if (fs.existsSync(rootDir)) {
    recurse(rootDir);
  }
  return results;
}

/**
 * Додаткові дії при деактивації (якщо потрібно).
 */
export function deactivate(): void {
  // ...
}
