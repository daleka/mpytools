// fileManager.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { exec } from 'child_process';

import { mpyOutputChannel } from './extension'; 
import { micropythonSysName } from './extension'; // Використовуємо sysname, наприклад "pyboard"

function getSelectedPort(): string {
  return (global as any).MPY_LAST_PORT || 'auto';
}

export function registerFileManager(context: vscode.ExtensionContext) {
  const provider = new FileManagerProvider();

  // Створюємо TreeView
  const treeView = vscode.window.createTreeView('mpytoolsFileExplorer', {
    treeDataProvider: provider
  });
  context.subscriptions.push(treeView);

  // Команда ручного refresh
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refresh', () => {
      provider.refresh();
    })
  );

  // FileSystemWatcher для src/** і mpy/**
  const srcWatcher = vscode.workspace.createFileSystemWatcher('**/src/**');
  const mpyWatcher = vscode.workspace.createFileSystemWatcher('**/mpy/**');

  srcWatcher.onDidCreate(() => provider.refresh());
  srcWatcher.onDidChange(() => provider.refresh());
  srcWatcher.onDidDelete(() => provider.refresh());

  mpyWatcher.onDidCreate(() => provider.refresh());
  mpyWatcher.onDidChange(() => provider.refresh());
  mpyWatcher.onDidDelete(() => provider.refresh());

  context.subscriptions.push(srcWatcher, mpyWatcher);
}

class FileManagerProvider implements vscode.TreeDataProvider<FileItem> {
  private _onDidChangeTreeData: vscode.EventEmitter<FileItem | undefined | void> =
    new vscode.EventEmitter<FileItem | undefined | void>();
  readonly onDidChangeTreeData: vscode.Event<FileItem | undefined | void> =
    this._onDidChangeTreeData.event;

  constructor() {
    // ...
  }

  public refresh(): void {
    this._onDidChangeTreeData.fire();
  }

  getTreeItem(element: FileItem): vscode.TreeItem {
    return element;
  }

  async getChildren(element?: FileItem): Promise<FileItem[]> {
    if (!element) {
      const mpySize = this.getLocalFolderSize('mpy');
      const srcSize = this.getLocalFolderSize('src');

      const mpyItem = new FileItem(
        `🗂 mpy (${mpySize} KB)`,
        vscode.TreeItemCollapsibleState.Collapsed,
        'local-mpy',
        this.getWorkspacePath('mpy')
      );
      const srcItem = new FileItem(
        `📂 src (${srcSize} KB)`,
        vscode.TreeItemCollapsibleState.Collapsed,
        'local-src',
        this.getWorkspacePath('src')
      );

      const rootNodes: FileItem[] = [mpyItem, srcItem];

      if (getSelectedPort() !== 'auto') {
        const label = micropythonSysName
          ? `🤖 ${micropythonSysName}`
          : 'device (click to expand)';
        const deviceItem = new FileItem(
          label,
          vscode.TreeItemCollapsibleState.Collapsed,
          'device-root',
          '/'
        );
        rootNodes.push(deviceItem);
      }

      return rootNodes;
    }

    switch (element.contextValue) {
      case 'local-mpy':
      case 'local-mpy-folder':
      case 'local-mpy-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('mpy');
        if (!safePath) {
          return [];
        }
        return this.readLocalDirectory(safePath, 'local-mpy-file', false);
      }
      case 'local-src':
      case 'local-src-folder':
      case 'local-src-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('src');
        if (!safePath) {
          return [];
        }
        return this.readLocalDirectory(safePath, 'local-src-file', true);
      }
      case 'device-root':
      case 'device-folder': {
        return this.readDeviceDirectory(element.fullPath || '/', 'device-file');
      }
      default:
        return [];
    }
  }

  private async readLocalDirectory(
    dirPath: string,
    baseContextValue: string,
    expandFolders: boolean
  ): Promise<FileItem[]> {
    if (!fs.existsSync(dirPath)) {
      return [];
    }
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    const result: FileItem[] = [];

    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      const isDir = entry.isDirectory();

      let collapsible = vscode.TreeItemCollapsibleState.None;
      if (isDir) {
        collapsible = expandFolders
          ? vscode.TreeItemCollapsibleState.Expanded
          : vscode.TreeItemCollapsibleState.Collapsed;
      }

      let contextVal = baseContextValue;
      if (isDir) {
        contextVal += '-folder';
      }

      const iconEmoji = this.getEmojiForFile(isDir, entry.name);
      const label = iconEmoji + ' ' + entry.name;

      result.push(
        new FileItem(label, collapsible, contextVal, fullPath)
      );
    }
    return result;
  }

  /**
   * Кожного разу при розгортанні папки пристрою:
   * 1) Закриваємо старий термінал
   * 2) Чекаємо 300 мс
   * 3) Формуємо команду mpremote... fs ls
   * 4) Виконуємо -> отримуємо рядки
   * 5) Парсимо (пропускаємо рядки "ls :...", розбираємо "<size> <name>")
   * 6) Створюємо новий термінал
   * 7) Повертаємо FileItem[]
   */
  private async readDeviceDirectory(
    devicePath: string,
    baseContextValue: string
  ): Promise<FileItem[]> {
    const port = getSelectedPort();
    if (!port || port === 'auto') {
      return [];
    }

    mpyOutputChannel.appendLine(`[readDeviceDirectory] Closing existing MPY terminals...`);
    vscode.window.terminals
      .filter(t => t.name.startsWith('MPY'))
      .forEach(t => t.dispose());

    mpyOutputChannel.appendLine(`[readDeviceDirectory] Waiting 300ms after terminal close...`);
    await new Promise(resolve => setTimeout(resolve, 300));

    const cmd = `mpremote connect ${port} fs ls ${devicePath}`;
    mpyOutputChannel.appendLine(`[readDeviceDirectory] Will run command: ${cmd}`);

    let rawLines: string[] = [];
    try {
      const output = await execPromise(cmd);
      rawLines = output.split('\n').map(l => l.trim()).filter(Boolean);
      mpyOutputChannel.appendLine(`[readDeviceDirectory] Raw LS lines:\n${rawLines.join('\n')}`);
    } catch (err: any) {
      mpyOutputChannel.appendLine(`[readDeviceDirectory] Error: ${err.message}`);
      return [];
    }

    // Створюємо новий термінал
    mpyOutputChannel.appendLine(`[readDeviceDirectory] Creating new terminal "MPY Session"...`);
    const newTerm = vscode.window.createTerminal('MPY Session');
    newTerm.show();

    const connectCmd = `mpremote connect ${port}`;
    mpyOutputChannel.appendLine(`[readDeviceDirectory] Sending to terminal: ${connectCmd}`);
    newTerm.sendText(connectCmd);

    // Тепер парсимо `rawLines`
    const items: FileItem[] = [];
    for (let line of rawLines) {
      // Пропускаємо "ls :/" тощо
      if (line.startsWith('ls :')) {
        mpyOutputChannel.appendLine(`[readDeviceDirectory] Skipping line (seems service): "${line}"`);
        continue;
      }

      // Спробуємо розбити "0 flash/" -> [ "0", "flash/" ]
      const parts = line.split(/\s+/, 2); 
      if (parts.length < 2) {
        mpyOutputChannel.appendLine(`[readDeviceDirectory] Skipping line (cannot parse "size name"): "${line}"`);
        continue;
      }

      let sizePart = parts[0];       // "0"
      let namePart = parts[1];       // "flash/" або "main.py"

      // Якщо namePart закінчується "/", вважаємо це папкою
      let isDir = false;
      if (namePart.endsWith('/')) {
        isDir = true;
        // Обрізаємо "/" для адекватного відображення
        namePart = namePart.replace(/\/+$/, '');
      }

      // Готуємо collapsibleState
      let collapsible = isDir
        ? vscode.TreeItemCollapsibleState.Collapsed
        : vscode.TreeItemCollapsibleState.None;

      // Якщо папка -> contextValue="device-folder"
      let childContext = isDir ? 'device-folder' : baseContextValue;

      // Формуємо шлях
      let childPath = devicePath;
      if (!childPath.endsWith('/')) {
        childPath += '/';
      }
      childPath += namePart;

      const iconEmoji = this.getEmojiForFile(isDir, namePart);
      const label = iconEmoji + ' ' + namePart;

      mpyOutputChannel.appendLine(`[readDeviceDirectory] -> item: size=${sizePart}, name="${namePart}", isDir=${isDir}`);
      items.push(
        new FileItem(label, collapsible, childContext, childPath)
      );
    }

    return items;
  }

  private getEmojiForFile(isDir: boolean, fname: string): string {
    if (isDir) {
      return '📁';
    }
    const ext = path.extname(fname).toLowerCase();
    switch (ext) {
      case '.py': return '🐍';
      case '.mpy': return '📦';
      case '.html': return '🌐';
      case '.css': return '🎨';
      case '.js': return '⚡';
      case '.json': return '🧮';
      case '.xml': return '🔖';
      case '.txt': return '📜';
      case '.csv': return '📊';
      case '.yaml':
      case '.yml': return '🏷️';
      default:
        return '📄';
    }
  }

  private getLocalFolderSize(relativePath: string): number {
    const dirPath = this.getWorkspacePath(relativePath);
    if (!dirPath || !fs.existsSync(dirPath)) {
      return 0;
    }
    let totalSize = 0;

    function recurse(folder: string) {
      const entries = fs.readdirSync(folder, { withFileTypes: true });
      for (const e of entries) {
        const full = path.join(folder, e.name);
        if (e.isDirectory()) {
          recurse(full);
        } else {
          totalSize += fs.statSync(full).size;
        }
      }
    }
    recurse(dirPath);
    return Math.floor(totalSize / 1024);
  }

  private getWorkspacePath(rel: string): string | undefined {
    const wsFolders = vscode.workspace.workspaceFolders;
    if (!wsFolders || wsFolders.length === 0) {
      return undefined;
    }
    return path.join(wsFolders[0].uri.fsPath, rel);
  }
}

class FileItem extends vscode.TreeItem {
  constructor(
    public readonly label: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly contextValue: string,
    public readonly fullPath?: string
  ) {
    super(label, collapsibleState);
  }
}

/** Виконання shell-команд */
function execPromise(cmd: string): Promise<string> {
  return new Promise((resolve, reject) => {
    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        return reject(error);
      }
      if (stderr && stderr.trim()) {
        return reject(new Error(stderr.trim()));
      }
      resolve(stdout);
    });
  });
}

// (Опціональна) команда для відкриття папки
vscode.commands.registerCommand('mpytools.openMicroPythonProject', async () => {
  const selected = await vscode.window.showOpenDialog({
    canSelectFiles: false,
    canSelectFolders: true,
    canSelectMany: false,
    openLabel: 'Open MicroPython Project'
  });
  if (selected && selected.length > 0) {
    vscode.commands.executeCommand('vscode.openFolder', selected[0]);
  }
});
