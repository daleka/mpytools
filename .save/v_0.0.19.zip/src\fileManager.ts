import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { exec } from 'child_process';

import { mpyOutputChannel } from './extension';
import { micropythonSysName } from './extension';

function getSelectedPort(): string {
  return (global as any).MPY_LAST_PORT || 'auto';
}

export function registerFileManager(context: vscode.ExtensionContext) {
  const provider = new FileManagerProvider();

  // Створюємо TreeView
  const treeView = vscode.window.createTreeView('mpytoolsFileExplorer', {
    treeDataProvider: provider
  });
  context.subscriptions.push(treeView);

  // Команда ручного refresh (оновлює все дерево)
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refresh', () => {
      provider.refresh();
    })
  );

  // (ІСНУЮЧА) Команда “Refresh folder”
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshFolder', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // (НОВЕ!) Команда “Refresh device”
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshDevice', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // Автоматичне оновлення видалено – тепер дерево оновлюється лише вручну!
}

class FileManagerProvider implements vscode.TreeDataProvider<FileItem> {
  private _onDidChangeTreeData: vscode.EventEmitter<FileItem | undefined | void> =
    new vscode.EventEmitter<FileItem | undefined | void>();
  readonly onDidChangeTreeData: vscode.Event<FileItem | undefined | void> =
    this._onDidChangeTreeData.event;

  constructor() {
    // ...
  }

  public refresh(item?: FileItem): void {
    this._onDidChangeTreeData.fire(item);
  }

  getTreeItem(element: FileItem): vscode.TreeItem {
    return element;
  }

  async getChildren(element?: FileItem): Promise<FileItem[]> {
    if (!element) {
      const mpySize = this.getLocalFolderSize('mpy');
      const srcSize = this.getLocalFolderSize('src');

      const mpyItem = new FileItem(
        `🗂 mpy (${mpySize} KB)`,
        vscode.TreeItemCollapsibleState.Collapsed,
        'local-mpy',
        this.getWorkspacePath('mpy')
      );

      const srcItem = new FileItem(
        `📂 src (${srcSize} KB)`,
        vscode.TreeItemCollapsibleState.Collapsed,
        'local-src',
        this.getWorkspacePath('src')
      );

      const rootNodes: FileItem[] = [mpyItem, srcItem];

      if ((global as any).MPY_LAST_PORT !== undefined) {
        const label = micropythonSysName
          ? `🤖 ${micropythonSysName}`
          : 'device (click to expand)';
        const deviceItem = new FileItem(
          label,
          vscode.TreeItemCollapsibleState.Collapsed,
          'device-root',
          '/'
        );
        rootNodes.push(deviceItem);
      }
      return rootNodes;
    }

    switch (element.contextValue) {
      case 'local-mpy':
      case 'local-mpy-folder':
      case 'local-mpy-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('mpy');
        if (!safePath) {
          return [];
        }
        return this.readLocalDirectory(safePath, 'local-mpy-file', false);
      }
      case 'local-src':
      case 'local-src-folder':
      case 'local-src-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('src');
        if (!safePath) {
          return [];
        }
        return this.readLocalDirectory(safePath, 'local-src-file', true);
      }
      case 'device-root':
      case 'device-folder': {
        if (!element.isLoaded) {
          const children = await this.readDeviceDirectory(element.fullPath || '/', 'device-file');
          if (element.contextValue === 'device-root') {
            const refreshItem = new FileItem(
              '🔄 Refresh',
              vscode.TreeItemCollapsibleState.None,
              'refresh-device',
              element.fullPath
            );
            refreshItem.command = {
              command: 'mpytoolsFileExplorer.refreshDevice',
              title: 'Refresh device',
              arguments: [element]
            };
            children.unshift(refreshItem);
          }
          element.cachedChildren = children;
          element.isLoaded = true;
          return children;
        } else {
          const children = element.cachedChildren || [];
          if (element.contextValue === 'device-root') {
            if (!children.some(child => child.contextValue === 'refresh-device')) {
              const refreshItem = new FileItem(
                '$(sync~spin) Refresh device',
                vscode.TreeItemCollapsibleState.None,
                'refresh-device',
                element.fullPath
              );
              refreshItem.command = {
                command: 'mpytoolsFileExplorer.refreshDevice',
                title: 'Refresh device',
                arguments: [element]
              };
              children.unshift(refreshItem);
            }
          }
          return children;
        }
      }
      default: {
        return [];
      }
    }
  }

  private async readLocalDirectory(
    dirPath: string,
    baseContextValue: string,
    expandFolders: boolean
  ): Promise<FileItem[]> {
    if (!fs.existsSync(dirPath)) {
      return [];
    }
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    const result: FileItem[] = [];
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      const isDir = entry.isDirectory();
      let collapsible = vscode.TreeItemCollapsibleState.None;
      if (isDir) {
        collapsible = expandFolders
          ? vscode.TreeItemCollapsibleState.Expanded
          : vscode.TreeItemCollapsibleState.Collapsed;
      }
      let contextVal = baseContextValue;
      if (isDir) {
        contextVal += '-folder';
      }
      const iconEmoji = this.getEmojiForFile(isDir, entry.name);
      const label = iconEmoji + ' ' + entry.name;
      result.push(new FileItem(label, collapsible, contextVal, fullPath));
    }
    return result;
  }

  private async readDeviceDirectory(
    devicePath: string,
    baseContextValue: string
  ): Promise<FileItem[]> {
    const port = getSelectedPort();
    if (!port) {
      return [];
    }
    // Видаляємо умову для "auto": тепер auto працює як звичайний порт
    vscode.window.terminals
      .filter(t => t.name.startsWith('MPY'))
      .forEach(t => { t.dispose(); });
    await new Promise(resolve => { resolve(true); });
    const cmd = `mpremote connect ${port} fs ls ${devicePath}`;
    let rawLines: string[] = [];
    try {
      const output = await execPromise(cmd);
      rawLines = output.split('\n').map(l => l.trim()).filter(Boolean);
    } catch (err: any) {
      mpyOutputChannel.appendLine(`[readDeviceDirectory] Error updating folder ${devicePath}: ${err.message}`);
      return [];
    }
    const items: FileItem[] = [];
    for (let line of rawLines) {
      if (line.startsWith('ls :')) {
        continue;
      }
      const parts = line.split(/\s+/, 2);
      if (parts.length < 2) {
        continue;
      }
      let namePart = parts[1];
      let isDir = false;
      if (namePart.endsWith('/')) {
        isDir = true;
        namePart = namePart.replace(/\/+$/, '');
      }
      let collapsible = isDir
        ? vscode.TreeItemCollapsibleState.Collapsed
        : vscode.TreeItemCollapsibleState.None;
      let childContext = isDir ? 'device-folder' : baseContextValue;
      let childPath = devicePath;
      if (!childPath.endsWith('/')) {
        childPath += '/';
      }
      childPath += namePart;
      const iconEmoji = this.getEmojiForFile(isDir, namePart);
      const label = iconEmoji + ' ' + namePart;
      items.push(new FileItem(label, collapsible, childContext, childPath));
    }
    mpyOutputChannel.show(true);
    mpyOutputChannel.appendLine(`✅ [readDeviceDirectory] Updated folder: ${devicePath}`);
    return items;
  }

  private getEmojiForFile(isDir: boolean, fname: string): string {
    if (isDir) {
      return '📁';
    }
    const ext = path.extname(fname).toLowerCase();
    switch (ext) {
      case '.py': {
        return '🐍';
      }
      case '.mpy': {
        return '📦';
      }
      case '.html': {
        return '🌐';
      }
      case '.css': {
        return '🎨';
      }
      case '.js': {
        return '⚡';
      }
      case '.json': {
        return '🧮';
      }
      case '.xml': {
        return '🔖';
      }
      case '.txt': {
        return '📜';
      }
      case '.csv': {
        return '📊';
      }
      case '.yaml':
      case '.yml': {
        return '🏷️';
      }
      default: {
        return '📄';
      }
    }
  }

  private getLocalFolderSize(relativePath: string): number {
    const dirPath = this.getWorkspacePath(relativePath);
    if (!dirPath || !fs.existsSync(dirPath)) {
      return 0;
    }
    let totalSize = 0;
    function recurse(folder: string) {
      const entries = fs.readdirSync(folder, { withFileTypes: true });
      for (const e of entries) {
        const full = path.join(folder, e.name);
        if (e.isDirectory()) {
          recurse(full);
        } else {
          totalSize += fs.statSync(full).size;
        }
      }
    }
    recurse(dirPath);
    return Math.floor(totalSize / 1024);
  }

  private getWorkspacePath(rel: string): string | undefined {
    const wsFolders = vscode.workspace.workspaceFolders;
    if (!wsFolders || wsFolders.length === 0) {
      return undefined;
    }
    return path.join(wsFolders[0].uri.fsPath, rel);
  }
}

class FileItem extends vscode.TreeItem {
  public isLoaded: boolean = false;
  public cachedChildren: FileItem[] | undefined;
  constructor(
    public readonly label: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly contextValue: string,
    public readonly fullPath?: string
  ) {
    super(label, collapsibleState);
  }
}

/** Виконує команду у оболонці та повертає Promise */
function execPromise(cmd: string): Promise<string> {
  return new Promise((resolve, reject) => {
    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        return reject(error);
      }
      if (stderr && stderr.trim()) {
        return reject(new Error(stderr.trim()));
      }
      resolve(stdout);
    });
  });
}

// (Опціональна) команда для відкриття папки
vscode.commands.registerCommand('mpytools.openMicroPythonProject', async () => {
  const selected = await vscode.window.showOpenDialog({
    canSelectFiles: false,
    canSelectFolders: true,
    canSelectMany: false,
    openLabel: 'Open MicroPython Project'
  });
  if (selected && selected.length > 0) {
    vscode.commands.executeCommand('vscode.openFolder', selected[0]);
  }
});
