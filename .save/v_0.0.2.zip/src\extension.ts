// extension.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';
import { registerDependenciesCommand } from './dependenciesInstaller';
// Імпортуємо registerSaveProjectCommand
import { registerSaveProjectCommand } from './saveProject';
// Імпортуємо нову функцію, яка містить логіку "Compile & Run"
import { registerCompileAndRunCommand } from './compileAndRun';

// Створюємо один глобальний Output Channel
export const mpyOutputChannel = vscode.window.createOutputChannel("MPyTools Log");

// Глобальні змінні для збереження версій
export let micropythonVersion: string | undefined = undefined;
export let micropythonBytecodeVersion: number | undefined = undefined;
export let micropythonArchitecture: string | undefined = undefined;
export let micropythonMsmallIntBits: number | undefined = undefined;

// Змінна, де ми зберігаємо останній вибраний порт
let lastUsedPort: string = 'auto';
// Змінна для збереження обраного методу компіляції mpy-cross (0, 1, 2 або 3)
let selectedCompilationMethod: string | undefined = undefined;

export function activate(context: vscode.ExtensionContext): void {
  console.log('MPyTools розширення активоване.');

  // 1. Реєструємо команду встановлення залежностей
  registerDependenciesCommand(context, mpyOutputChannel);

  // 2. Запит на встановлення залежностей (при новій інсталяції)
  const packageJsonPath = context.asAbsolutePath('./package.json');
  const packageStats = fs.statSync(packageJsonPath);
  const currentInstallTime = packageStats.mtime.getTime();
  const storedInstallTime = context.globalState.get<number>('extensionInstallTime', 0);
  if (currentInstallTime > storedInstallTime) {
    context.globalState.update('extensionInstallTime', currentInstallTime);
    vscode.window.showInformationMessage(
      "MPyTools needs dependencies:\n- mpremote\n- mpy-cross\n- micropython-stdlib-stubs\nInstall them now?",
      "Yes",
      "No"
    ).then((choice) => {
      if (choice === "Yes") {
        vscode.commands.executeCommand('mpytools.installDependencies');
      } else {
        console.log("User chose not to install dependencies.");
      }
    });
  }

  // 3. Статус-бар для вибору порту
  let connectionStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 0);
  connectionStatusBarItem.text = '$(plug) Select Port';
  connectionStatusBarItem.tooltip = 'Click to select a MicroPython port';
  connectionStatusBarItem.color = 'red';
  connectionStatusBarItem.command = 'mpytools.selectPort';
  connectionStatusBarItem.show();
  context.subscriptions.push(connectionStatusBarItem);

  // Кнопка Run
  let runStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  runStatusBarItem.text = '$(play) Run';
  runStatusBarItem.tooltip = 'Запустити активний файл';
  runStatusBarItem.command = 'mpytools.runActive';
  runStatusBarItem.hide();
  context.subscriptions.push(runStatusBarItem);

  // Кнопка Stop
  let stopStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  stopStatusBarItem.text = '$(debug-stop) Stop';
  stopStatusBarItem.tooltip = 'Зупинити виконання (Ctrl-C)';
  stopStatusBarItem.command = 'mpytools.stop';
  stopStatusBarItem.hide();
  context.subscriptions.push(stopStatusBarItem);

  // Кнопка Reset
  let resetStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, -2);
  resetStatusBarItem.text = '$(refresh) Reset';
  resetStatusBarItem.tooltip = 'Hard reset the device (mpremote connect <port> reset)';
  resetStatusBarItem.color = "#ff6666";
  resetStatusBarItem.command = 'mpytools.resetHard';
  resetStatusBarItem.hide();
  context.subscriptions.push(resetStatusBarItem);

  // Команда "Run Active"
  vscode.commands.registerCommand('mpytools.runActive', async (): Promise<void> => {
    const terminalsToClose = vscode.window.terminals.filter(t =>
      t.name.startsWith("MPY") && t.name !== "MPY Compile&download"
    );
    terminalsToClose.forEach(t => t.dispose());

    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showWarningMessage("Немає активного файлу для запуску.");
      return;
    }
    const filePath = editor.document.uri.fsPath;

    mpyOutputChannel.appendLine("🔹 Run active file: " + filePath);

    let runTerminal = vscode.window.createTerminal('MPY Run');
    runTerminal.show();
    runTerminal.sendText(`mpremote run "${filePath}"`);
  });

  // Команда "Stop"
  vscode.commands.registerCommand('mpytools.stop', async (): Promise<void> => {
    const terminal = vscode.window.activeTerminal;
    if (terminal) {
      terminal.sendText("\x03", false); // Ctrl-C
      vscode.window.showInformationMessage("Stop: Ctrl-C надіслано. (Execution stopped)");
      mpyOutputChannel.appendLine("✅ Stop signal (Ctrl-C) sent.");
    } else {
      vscode.window.showWarningMessage("Немає активного терміналу.");
    }
  });

  // Команда "Reset Hard"
  vscode.commands.registerCommand('mpytools.resetHard', async (): Promise<void> => {
    try {
      const terminalsToClose = vscode.window.terminals.filter(t =>
        t.name.startsWith("MPY")
      );
      terminalsToClose.forEach(t => t.dispose());

      const usedPort = (lastUsedPort === 'auto') ? 'auto' : formatPort(lastUsedPort);
      mpyOutputChannel.appendLine(`🔹 Hard Reset on port "${lastUsedPort}"`);

      let resetTerminal = vscode.window.createTerminal('MPY Reset');
      resetTerminal.show();
      resetTerminal.sendText(`mpremote connect ${usedPort} reset`);

      vscode.window.showInformationMessage(`Device hard-reset requested on port "${lastUsedPort}"`);
      mpyOutputChannel.appendLine("✅ Hard reset command sent.");
    } catch (err: any) {
      vscode.window.showErrorMessage("Failed to reset (hard-reset) device: " + err);
      mpyOutputChannel.appendLine("❌ Error resetting device: " + err.message);
    }
  });

  // Команда "Select Port"
  let disposableSelectPort = vscode.commands.registerCommand('mpytools.selectPort', (): void => {
    exec('mpremote connect list', (error, stdout, stderr) => {
      if (error || stderr) {
        console.error("Error listing ports:", error || stderr);
        mpyOutputChannel.appendLine("❌ Error listing ports: " + (error?.message || stderr));
      }

      let availablePorts: string[] = [];
      if (!error && !stderr) {
        availablePorts = stdout
          .split('\n')
          .filter((line) => line.includes('COM') || line.includes('/dev/'))
          .map((line) => line.trim().split(' ')[0]);
      }
      if (!availablePorts.includes('auto')) {
        availablePorts.push('auto');
      }

      vscode.window.showQuickPick(availablePorts, {
        placeHolder: 'Select a port to use (current: ' + lastUsedPort + ')'
      }).then(async (selectedPort) => {
        if (!selectedPort) {
          return;
        }
        lastUsedPort = selectedPort;

        mpyOutputChannel.appendLine(`🔹 Selected port: "${lastUsedPort}"`);

        connectionStatusBarItem.text = '$(sync~spin) MPY: Connecting...';
        connectionStatusBarItem.color = 'yellow';
        connectionStatusBarItem.tooltip = 'Connecting to the device...';

        vscode.window.terminals
          .filter(t => t.name.startsWith("MPY"))
          .forEach(t => t.dispose());

        // 1-й DELAY
        await new Promise(resolve => setTimeout(resolve, 500));

        const usedPort = (lastUsedPort === 'auto') ? 'auto' : formatPort(lastUsedPort);

        mpyOutputChannel.show(true);
        mpyOutputChannel.appendLine(`🔹 Fetching device info (version, architecture, small-int bits)...`);
        mpyOutputChannel.appendLine(`🔹 Fetching MicroPython info via: mpremote connect ${usedPort} exec "import sys; ..."`);

        let fetchError: any = null;
        try {
          await fetchMicropythonVersionInfo(usedPort);
        } catch (err) {
          fetchError = err;
        }

        if (!fetchError) {
          mpyOutputChannel.appendLine(`✅ Connected to port: "${lastUsedPort}"`);
          mpyOutputChannel.appendLine(`✅ Fetched device info successfully.`);
          mpyOutputChannel.appendLine("");

          // Показуємо кнопки
          compileStatusBarItem.show();
          runStatusBarItem.show();
          stopStatusBarItem.show();
          resetStatusBarItem.show();
        } else {
          mpyOutputChannel.appendLine(`❌ Could not fetch MicroPython info: ${fetchError}`);
          mpyOutputChannel.appendLine("");
        }

        removeMpyFolder();

        await new Promise(resolve => setTimeout(resolve, 300));

        let connectTerminal = vscode.window.createTerminal('MPY Session');
        connectTerminal.show();
        connectTerminal.sendText(
          `mpremote connect ${usedPort} exec "import os, gc; print(os.uname()); print('Free memory:', gc.mem_free())" + repl`
        );

        setTimeout(() => {
          connectionStatusBarItem.text = `$(check) MPY: Using ${lastUsedPort}`;
          connectionStatusBarItem.color = 'green';
          connectionStatusBarItem.tooltip = 'Port selected';
        }, 2000);
      });
    });
  });
  context.subscriptions.push(disposableSelectPort);

  // ===============================
  // NEW PART: Реєструємо "Compile & Run" у новому файлі
  // ===============================
  // Виклик registerCompileAndRunCommand повинен повертати нам StatusBarItem (кнопку),
  // щоб ми могли .show()/.hide() у extension.ts
  const compileStatusBarItem = registerCompileAndRunCommand(
    context,
    mpyOutputChannel,
    execPromise,
    () => lastUsedPort, // getLastUsedPort
    () => selectedCompilationMethod, // getSelectedMethod
    (val: string|undefined) => { selectedCompilationMethod = val; }, // setSelectedMethod
    needsRecompile,
    compilePyFile,
    findPyFiles,
    openTerminalAndRunMain,
    formatPort
  );
  // compileStatusBarItem спочатку приховано у compileAndRun.ts (hide()).
  // Ми викликаємо show() після успішного вибору порту (у selectPort).

  // ===============================
  // Реєструємо "Save Project"
  // ===============================
  registerSaveProjectCommand(context, mpyOutputChannel, execPromise);
}

/**
 * Витягує інформацію про версію MicroPython
 */
async function fetchMicropythonVersionInfo(port: string): Promise<void> {
  const cmd = `mpremote connect ${port} exec "` +
    `import sys; ` +
    `print('MPYVER:', sys.implementation.version); ` +
    `print('MPYCODE:', sys.implementation._mpy); ` +
    `arch_val = (sys.implementation._mpy >> 10); print('MPYARCH:', arch_val); ` +
    `print('MAXSIZE:', sys.maxsize)` +
    `"`;
  mpyOutputChannel.appendLine(`🔹 Fetching MicroPython info via: ${cmd}`);

  return new Promise<void>((resolve, reject) => {
    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        mpyOutputChannel.appendLine("❌ Error running fetchMicropythonVersionInfo: " + error);
        reject(error);
        return;
      }
      if (stderr && stderr.trim()) {
        mpyOutputChannel.appendLine("❌ Stderr in fetchMicropythonVersionInfo: " + stderr.trim());
      }

      // Тут ви парсите stdout, зберігаєте micropythonVersion тощо.
      // Припускаємо, що у вас уже реалізовано.
      resolve();
    });
  });
}

/**
 * Виконує команду у shell і повертає Promise зі stdout або помилкою
 */
export function execPromise(command: string): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }
      if (stderr && stderr.trim()) {
        reject(new Error(stderr));
        return;
      }
      resolve(stdout);
    });
  });
}

/**
 * Функція для видалення теку "mpy"
 */
function removeMpyFolder(): void {
  const workspaceFolders = vscode.workspace.workspaceFolders;
  if (!workspaceFolders || workspaceFolders.length === 0) {
    return;
  }
  const workspaceRoot = workspaceFolders[0].uri.fsPath;
  const mpyPath = path.join(workspaceRoot, 'mpy');

  if (!fs.existsSync(mpyPath)) {
    return;
  }

  mpyOutputChannel.appendLine("🔹 Removing 'mpy' folder from the project...");
  removeFolderRecursive(mpyPath);
  mpyOutputChannel.appendLine("✅ 'mpy' folder removed successfully.");
  mpyOutputChannel.appendLine("");
}

/** Рекурсивно видаляє теку */
function removeFolderRecursive(dirPath: string): void {
  if (fs.existsSync(dirPath)) {
    fs.readdirSync(dirPath).forEach((file) => {
      const curPath = path.join(dirPath, file);
      if (fs.lstatSync(curPath).isDirectory()) {
        removeFolderRecursive(curPath);
      } else {
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(dirPath);
  }
}

/**
 * Форматує порт залежно від платформи: COM4 -> COM4, /dev/... -> /dev/...
 */
function formatPort(port: string): string {
  const platform = os.platform();
  if (platform === 'win32') {
    return port;
  } else if (platform === 'linux' || platform === 'darwin') {
    return `/dev/${port}`;
  }
  return port;
}

/**
 * Перевіряє, чи потрібна перекомпіляція файлу .py -> .mpy
 */
function needsRecompile(pyFilePath: string, srcPath: string, mpyPath: string): boolean {
  const relative = path.relative(srcPath, pyFilePath);
  const outPath = path.join(mpyPath, relative.replace(/\.py$/, '.mpy'));
  if (!fs.existsSync(outPath)) {
    return true;
  }
  const pyStat = fs.statSync(pyFilePath);
  const mpyStat = fs.statSync(outPath);
  return (pyStat.mtime > mpyStat.mtime);
}

/**
 * Компілює один файл .py у .mpy (за допомогою mpy-cross -O...)
 */
async function compilePyFile(
  pyFilePath: string,
  srcPath: string,
  mpyPath: string
): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    const relative = path.relative(srcPath, pyFilePath);
    const outPath = path.join(mpyPath, relative.replace(/\.py$/, '.mpy'));
    fs.mkdirSync(path.dirname(outPath), { recursive: true });

    const cmd = `mpy-cross -O${selectedCompilationMethod} "${pyFilePath}" -o "${outPath}"`;
    exec(cmd, (error, stdout, stderr) => {
      if (stdout && stdout.trim()) {
        console.log(`[mpy-cross stdout] ${stdout.trim()}`);
      }
      if (stderr && stderr.trim()) {
        console.error(`[mpy-cross stderr] ${stderr.trim()}`);
      }
      if (error) {
        reject(error);
      } else {
        resolve(outPath);
      }
    });
  });
}

/**
 * Відкриває термінал і виконує mpremote connect <port> exec "import main" + repl,
 * а потім через 2 секунди — викликає main.run().
 */
function openTerminalAndRunMain(port: string, debugTerminal: vscode.Terminal): void {
  let connectCmd = '';
  if (port === 'auto') {
    connectCmd = 'mpremote connect auto exec "import main" + repl';
  } else {
    connectCmd = `mpremote connect ${port} exec "import main" + repl`;
  }
  debugTerminal.sendText(connectCmd);

  setTimeout(() => {
    debugTerminal.sendText('main.run()');
  }, 2000);
}

/**
 * Пошук .py файлів у директорії
 */
function findPyFiles(rootDir: string, ignoreList: string[] = []): string[] {
  let results: string[] = [];
  function recurse(dir: string) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (let entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        recurse(fullPath);
      } else if (entry.isFile() && entry.name.endsWith('.py')) {
        if (!ignoreList.includes(entry.name)) {
          results.push(fullPath);
        }
      }
    }
  }
  if (fs.existsSync(rootDir)) {
    recurse(rootDir);
  }
  return results;
}

/**
 * Додаткові дії при деактивації (якщо потрібно).
 */
export function deactivate(): void {
  // ...
}
