// fileManager.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';

import { mpyOutputChannel } from './extension';
import { micropythonSysName } from './extension';

function getSelectedPort(): string {
  return (global as any).MPY_LAST_PORT || 'auto';
}

// Глобальна мапа для збереження відповідності тимчасових файлів з пристрою
// Ключ – шлях до тимчасового файлу, значення – шлях на пристрої
const deviceFileMapping: Map<string, string> = new Map();

export function registerFileManager(context: vscode.ExtensionContext) {
  const provider = new FileManagerProvider();

  // Створюємо TreeView
  const treeView = vscode.window.createTreeView('mpytoolsFileExplorer', {
    treeDataProvider: provider
  });
  context.subscriptions.push(treeView);

  // Команда глобального refresh (перемалювати дерево)
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refresh', () => {
      provider.refresh();
    })
  );

  // Команда "Refresh folder"
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshFolder', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // Команда "Refresh device"
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshDevice', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // Додаткова команда відкрити проект
  vscode.commands.registerCommand('mpytools.openMicroPythonProject', async () => {
    const selected = await vscode.window.showOpenDialog({
      canSelectFiles: false,
      canSelectFolders: true,
      canSelectMany: false,
      openLabel: 'Open MicroPython Project'
    });
    if (selected && selected.length > 0) {
      vscode.commands.executeCommand('vscode.openFolder', selected[0]);
    }
  });

  // Команда для відкриття файлів
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.openFile', async (item: FileItem) => {
      if (!item.fullPath) {
        return;
      }
      // Якщо це локальний файл, використовуємо стандартне відкриття
      if (item.contextValue.startsWith('local-')) {
        const document = await vscode.workspace.openTextDocument(item.fullPath);
        vscode.window.showTextDocument(document);
      }
      // Якщо це файл на пристрої, завантажуємо його через mpremote і відкриваємо з тимчасового місця
      else if (item.contextValue === 'device-file') {
        try {
          const port = getSelectedPort();
          // Додаємо порт до команди: mpremote connect <port> fs cat <file>
          const cmd = `mpremote connect ${port} fs cat ${item.fullPath}`;
          const output = await execPromise(cmd);
          // Створюємо тимчасову папку для файлів з пристрою
          const tempDir = path.join(os.tmpdir(), 'mpytools-device-files');
          if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
          }
          // Генеруємо ім'я файлу на основі device path (замінюємо "/" та заборонені символи на "_")
          const relativeName = item.fullPath.replace(/^\//, '').replace(/[\/\\:]/g, '_');
          const tempFilePath = path.join(tempDir, relativeName);
          fs.writeFileSync(tempFilePath, output, 'utf8');
          // Запам'ятовуємо відповідність тимчасового файлу та шляху на пристрої для подальшого збереження
          deviceFileMapping.set(tempFilePath, item.fullPath);
          const document = await vscode.workspace.openTextDocument(tempFilePath);
          vscode.window.showTextDocument(document);
        } catch (err: any) {
          mpyOutputChannel.appendLine(`[openFile] Error opening device file ${item.fullPath}: ${err.message}`);
          vscode.window.showErrorMessage(`Error opening device file: ${err.message}`);
        }
      }
    })
  );

  // Відслідковуємо подію збереження файлу для завантаження змін назад на пристрій
  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument(async (document) => {
      const filePath = document.fileName;
      if (deviceFileMapping.has(filePath)) {
        const devicePath = deviceFileMapping.get(filePath)!;
        try {
          const port = getSelectedPort();
          // Завантажуємо файл з тимчасового сховища назад на пристрій; для команди cp перед devicePath додаємо ":"
          const cmd = `mpremote connect ${port} fs cp ${filePath} :${devicePath} -f`;
          await execPromise(cmd);
          mpyOutputChannel.appendLine(`[uploadFile] Uploaded ${filePath} to device at ${devicePath}`);
          vscode.window.showInformationMessage(`File uploaded to device: ${devicePath}`);
        } catch (err: any) {
          mpyOutputChannel.appendLine(`[uploadFile] Error uploading file ${filePath} to device: ${err.message}`);
          vscode.window.showErrorMessage(`Error uploading file to device: ${err.message}`);
        }
      }
    })
  );
}

class FileManagerProvider implements vscode.TreeDataProvider<FileItem> {
  private _onDidChangeTreeData: vscode.EventEmitter<FileItem | undefined | void> =
    new vscode.EventEmitter<FileItem | undefined | void>();
  readonly onDidChangeTreeData: vscode.Event<FileItem | undefined | void> =
    this._onDidChangeTreeData.event;

  public refresh(item?: FileItem): void {
    this._onDidChangeTreeData.fire(item);
  }

  getTreeItem(element: FileItem): vscode.TreeItem {
    return element;
  }

  async getChildren(element?: FileItem): Promise<FileItem[]> {
    // Якщо root (немає батька)
    if (!element) {
      const mpySize = this.getLocalFolderSize('mpy');
      const srcSize = this.getLocalFolderSize('src');

      // Вузол mpy
      const mpyItem = new FileItem(
        `📁 mpy (${mpySize} KB)`,
        vscode.TreeItemCollapsibleState.Collapsed,
        'local-mpy',
        this.getWorkspacePath('mpy')
      );

      // Вузол src
      const srcItem = new FileItem(
        `📂 src (${srcSize} KB)`,
        vscode.TreeItemCollapsibleState.Expanded,
        'local-src',
        this.getWorkspacePath('src')
      );

      const rootNodes: FileItem[] = [mpyItem, srcItem];

      // Якщо вибрано порт, додаємо вузол пристрою:
      if ((global as any).MPY_LAST_PORT !== undefined) {
        const label = micropythonSysName
          ? `🔲 ${micropythonSysName}`
          : 'device (click to expand)';

        // Генеруємо унікальний id, щоб VSCode сприймав його як "новий" вузол і примусово згортав
        const deviceId = 'device-root-' + (global as any).MPY_LAST_PORT + '-' + Date.now();

        const deviceItem = new FileItem(
          label,
          vscode.TreeItemCollapsibleState.Collapsed, // завжди починаємо згорнутим
          'device-root',
          '/'
        );
        deviceItem.id = deviceId;
        deviceItem.isLoaded = false;
        deviceItem.cachedChildren = undefined;

        rootNodes.push(deviceItem);
      }
      return rootNodes;
    }

    // Якщо отримуємо дітей для певного елемента
    switch (element.contextValue) {
      case 'local-mpy':
      case 'local-mpy-folder':
      case 'local-mpy-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('mpy');
        if (!safePath) {
          return [];
        }
        const children = await this.readLocalDirectory(safePath, 'local-mpy-file', false);
        element.isLoaded = true;
        element.cachedChildren = children;
        return children;
      }
      case 'local-src':
      case 'local-src-folder':
      case 'local-src-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('src');
        if (!safePath) {
          return [];
        }
        const children = await this.readLocalDirectory(safePath, 'local-src-file', true);
        element.isLoaded = true;
        element.cachedChildren = children;
        return children;
      }
      case 'device-root':
      case 'device-folder': {
        // Якщо ще не завантажено
        if (!element.isLoaded) {
          const children = await this.readDeviceDirectory(element.fullPath || '/', 'device-file');

          // Якщо це кореневий вузол пристрою, додамо пункт Refresh
          if (element.contextValue === 'device-root') {
            const refreshItem = new FileItem(
              '♻️ Refresh',
              vscode.TreeItemCollapsibleState.None,
              'refresh-device',
              element.fullPath
            );
            refreshItem.command = {
              command: 'mpytoolsFileExplorer.refreshDevice',
              title: 'Refresh device',
              arguments: [element]
            };
            children.unshift(refreshItem);
          }

          element.isLoaded = true;
          element.cachedChildren = children;
          return children;
        } else {
          // Якщо вже завантажено, повертаємо з кешу
          return element.cachedChildren || [];
        }
      }
      default: {
        return [];
      }
    }
  }

  // Для локальних файлів: призначаємо resourceUri = vscode.Uri.file(...),
  // щоб відображалися іконки зі стандартної теми
  private async readLocalDirectory(
    dirPath: string,
    baseContextValue: string,
    expandFolders: boolean
  ): Promise<FileItem[]> {
    if (!fs.existsSync(dirPath)) {
      return [];
    }
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    const result: FileItem[] = [];

    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      const isDir = entry.isDirectory();

      let collapsible = vscode.TreeItemCollapsibleState.None;
      if (isDir) {
        collapsible = expandFolders
          ? vscode.TreeItemCollapsibleState.Expanded
          : vscode.TreeItemCollapsibleState.Collapsed;
      }

      let contextVal = baseContextValue;
      if (isDir) {
        contextVal += '-folder';
      }

      const label = entry.name;
      const fileItem = new FileItem(label, collapsible, contextVal, fullPath);

      // Застосувати іконки теми для локальних файлів/папок
      fileItem.resourceUri = vscode.Uri.file(fullPath);

      // Якщо це файл (не папка), додамо команду для відкриття
      if (!isDir) {
        fileItem.command = {
          command: 'mpytoolsFileExplorer.openFile',
          title: 'Open File',
          arguments: [fileItem]
        };
      }

      result.push(fileItem);
    }
    return result;
  }

  // Для файлів на пристрої: зберігаємо реальний device-path в fullPath,
  // а окремо створюємо fakeLocalPath для resourceUri.
  private async readDeviceDirectory(
    devicePath: string,
    baseContextValue: string
  ): Promise<FileItem[]> {
    const port = getSelectedPort();
    if (!port) {
      return [];
    }

    // Закриваємо MPY-термінали
    vscode.window.terminals
      .filter(t => t.name.startsWith('MPY'))
      .forEach(t => t.dispose());
    await new Promise(resolve => setTimeout(resolve, 300));

    const cmd = `mpremote connect ${port} fs ls ${devicePath}`;
    let rawLines: string[] = [];
    try {
      const output = await execPromise(cmd);
      rawLines = output.split('\n').map(l => l.trim()).filter(Boolean);
    } catch (err: any) {
      mpyOutputChannel.appendLine(
        `[readDeviceDirectory] ⚠️ Error updating folder ${devicePath}: ${err.message}`
      );
      return [];
    }

    const items: FileItem[] = [];
    for (let line of rawLines) {
      // інколи mpremote виводить "ls :/flash", пропускаємо
      if (line.startsWith('ls :')) {
        continue;
      }
      const parts = line.split(/\s+/, 2);
      if (parts.length < 2) {
        continue;
      }
      let namePart = parts[1];
      let isDir = false;
      if (namePart.endsWith('/')) {
        isDir = true;
        namePart = namePart.replace(/\/+$/, '');
      }

      const collapsible = isDir
        ? vscode.TreeItemCollapsibleState.Collapsed
        : vscode.TreeItemCollapsibleState.None;
      const childContext = isDir ? 'device-folder' : baseContextValue;

      // Реальний шлях на пристрої, який треба передати mpremote:
      // Якщо поточний devicePath вже закінчується на '/', то додаємо без додаткового слеша
      const childDevicePath = devicePath.endsWith('/')
        ? devicePath + namePart
        : devicePath + '/' + namePart;

      // Створюємо "фейковий" локальний шлях для resourceUri,
      // використовуючи os.tmpdir() та замінюючи заборонені символи для коректності на всіх ОС
      const iconTempDir = path.join(os.tmpdir(), 'mpytools-device-icons');
      if (!fs.existsSync(iconTempDir)) {
        fs.mkdirSync(iconTempDir, { recursive: true });
      }
      const fakeLocalPath = path.join(
        iconTempDir,
        childDevicePath.replace(/[\/\\:]/g, '_')
      );

      const label = namePart;
      const fileItem = new FileItem(label, collapsible, childContext, childDevicePath);

      // Використовуємо "фейковий" шлях тільки для іконок
      fileItem.resourceUri = vscode.Uri.file(fakeLocalPath);

      // Ставимо новий id, щоб не зберігався старий стан розгортання
      fileItem.id = `device-item-${childDevicePath}-${Date.now()}`;

      // Якщо це файл (не папка), додамо команду для відкриття
      if (!isDir) {
        fileItem.command = {
          command: 'mpytoolsFileExplorer.openFile',
          title: 'Open File',
          arguments: [fileItem]
        };
      }

      items.push(fileItem);
    }

    mpyOutputChannel.show(true);
    mpyOutputChannel.appendLine(`> [readDeviceDirectory] Updated folder: ${devicePath}`);
    return items;
  }

  private getLocalFolderSize(relativePath: string): number {
    const dirPath = this.getWorkspacePath(relativePath);
    if (!dirPath || !fs.existsSync(dirPath)) {
      return 0;
    }
    let totalSize = 0;
    function recurse(folder: string) {
      const entries = fs.readdirSync(folder, { withFileTypes: true });
      for (const e of entries) {
        const full = path.join(folder, e.name);
        if (e.isDirectory()) {
          recurse(full);
        } else {
          totalSize += fs.statSync(full).size;
        }
      }
    }
    recurse(dirPath);
    return Math.floor(totalSize / 1024);
  }

  private getWorkspacePath(rel: string): string | undefined {
    const wsFolders = vscode.workspace.workspaceFolders;
    if (!wsFolders || wsFolders.length === 0) {
      return undefined;
    }
    return path.join(wsFolders[0].uri.fsPath, rel);
  }
}

class FileItem extends vscode.TreeItem {
  public isLoaded: boolean = false;
  public cachedChildren: FileItem[] | undefined;
  constructor(
    public readonly label: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly contextValue: string,
    /**
     * Зберігаємо тут **реальний** шлях на пристрої (або локальний),
     * який далі використовується для mpremote (для віддалених) або fs-операцій (для локальних)
     */
    public readonly fullPath?: string
  ) {
    super(label, collapsibleState);
  }
}

/** Виконати exec з Promise */
function execPromise(cmd: string): Promise<string> {
  return new Promise((resolve, reject) => {
    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        return reject(error);
      }
      if (stderr && stderr.trim()) {
        return reject(new Error(stderr.trim()));
      }
      resolve(stdout);
    });
  });
}
