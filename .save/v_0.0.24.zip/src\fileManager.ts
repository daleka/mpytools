// fileManager.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';

import { mpyOutputChannel } from './extension';
import { micropythonSysName } from './extension';

// Допоміжна функція для канонізації шляху (нормалізація та приведення до нижнього регістру)
function getCanonicalPath(p: string): string {
  return path.normalize(p).toLowerCase();
}

// Глобальна мапа для збереження відповідності тимчасового файлу та реального device-шляху
const deviceFileMap = new Map<string, string>();

function getSelectedPort(): string {
  return (global as any).MPY_LAST_PORT || 'auto';
}

export function registerFileManager(context: vscode.ExtensionContext) {
  const provider = new FileManagerProvider();

  // Створюємо TreeView
  const treeView = vscode.window.createTreeView('mpytoolsFileExplorer', {
    treeDataProvider: provider
  });
  context.subscriptions.push(treeView);

  // Команда глобального refresh (перемалювати дерево)
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refresh', () => {
      provider.refresh();
    })
  );

  // Команда "Refresh folder"
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshFolder', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // Команда "Refresh device"
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshDevice', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // Додаткова команда відкрити проект
  vscode.commands.registerCommand('mpytools.openMicroPythonProject', async () => {
    const selected = await vscode.window.showOpenDialog({
      canSelectFiles: false,
      canSelectFolders: true,
      canSelectMany: false,
      openLabel: 'Open MicroPython Project'
    });
    if (selected && selected.length > 0) {
      vscode.commands.executeCommand('vscode.openFolder', selected[0]);
    }
  });

  // Команда для відкриття файлів з пристрою
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytools.openDeviceFile', async (item: FileItem) => {
      if (!item.fullPath) {
        return;
      }
      try {
        mpyOutputChannel.appendLine(`📥 Opening device file: ${item.fullPath}`);
        await openDeviceFile(item);
      } catch (err: any) {
        vscode.window.showErrorMessage(`Failed to open device file: ${err.message}`);
      }
    })
  );

  // Обробка збереження файлів з пристрою – завантаження відбувається лише при збереженні
  vscode.workspace.onDidSaveTextDocument(async (document) => {
    const localPath = getCanonicalPath(document.uri.fsPath);
    if (deviceFileMap.has(localPath)) {
      const devicePath = deviceFileMap.get(localPath)!;
      try {
        await uploadDeviceFile(localPath, devicePath);
        mpyOutputChannel.appendLine(`✅ Uploaded file to device: ${devicePath}`);
        deviceFileMap.delete(localPath);
      } catch (err: any) {
        vscode.window.showErrorMessage(`Failed to upload ${localPath} to device: ${err.message}`);
      }
    }
  });

  // Видалено обробку події закриття документа,
  // щоб автоматичне завантаження не відбувалося при простому закритті без збереження.
}

// Функція, яка відкриває файл з пристрою:
// 1. Завантажує файл з пристрою у тимчасову директорію за допомогою mpremote,
// 2. Відкриває файл у VSCode,
// 3. Зберігає відповідність локального тимчасового шляху та device-шляху для подальшого завантаження зміненого файлу.
async function openDeviceFile(fileItem: FileItem): Promise<void> {
  const devicePath = fileItem.fullPath!;
  const port = getSelectedPort();
  // Підготовка тимчасової директорії
  const tempDir = path.join(os.tmpdir(), 'mpytools_temp');
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
  }
  // Формування імені тимчасового файлу з збереженням оригінального розширення
  const baseName = path.basename(fileItem.label, path.extname(fileItem.label));
  const ext = path.extname(fileItem.label);
  const tempFileName = `${baseName}-${Date.now()}${ext}`;
  const tempFilePath = path.join(tempDir, tempFileName);

  mpyOutputChannel.appendLine(`⬇️ Downloading file from device: ${devicePath}`);
  // Завантаження файлу з пристрою у тимчасовий файл
  await downloadDeviceFile(devicePath, tempFilePath);

  // Відкриття тимчасового файлу у VSCode
  const document = await vscode.workspace.openTextDocument(tempFilePath);
  await vscode.window.showTextDocument(document, { preview: false });

  // Збереження відповідності для подальшого завантаження при збереженні
  const canonicalTempPath = getCanonicalPath(tempFilePath);
  deviceFileMap.set(canonicalTempPath, devicePath);
  mpyOutputChannel.appendLine(`🔗 Mapping set: ${canonicalTempPath} -> ${devicePath}`);
}

// Допоміжна функція для завантаження файлу з пристрою
async function downloadDeviceFile(devicePath: string, localPath: string): Promise<void> {
  const port = getSelectedPort();
  const cmd = `mpremote connect ${port} fs cp :${devicePath} ${localPath}`;
  try {
    await execPromise(cmd);
    mpyOutputChannel.appendLine(`⬇️ Download complete: ${localPath}`);
  } catch (err: any) {
    throw err;
  }
}

// Допоміжна функція для завантаження файлу з локальної тимчасової директорії на пристрій
async function uploadDeviceFile(localPath: string, devicePath: string): Promise<void> {
  const port = getSelectedPort();
  const cmd = `mpremote connect ${port} fs cp -f ${localPath} :${devicePath}`;
  try {
    await execPromise(cmd);
    mpyOutputChannel.appendLine(`⬆️ Upload complete: ${localPath} to ${devicePath}`);
  } catch (err: any) {
    throw err;
  }
}

class FileManagerProvider implements vscode.TreeDataProvider<FileItem> {
  private _onDidChangeTreeData: vscode.EventEmitter<FileItem | undefined | void> =
    new vscode.EventEmitter<FileItem | undefined | void>();
  readonly onDidChangeTreeData: vscode.Event<FileItem | undefined | void> =
    this._onDidChangeTreeData.event;

  public refresh(item?: FileItem): void {
    this._onDidChangeTreeData.fire(item);
  }

  getTreeItem(element: FileItem): vscode.TreeItem {
    return element;
  }

  async getChildren(element?: FileItem): Promise<FileItem[]> {
    // Якщо root (немає батька)
    if (!element) {
      const mpySize = this.getLocalFolderSize('mpy');
      const srcSize = this.getLocalFolderSize('src');

      // Вузол mpy
      const mpyItem = new FileItem(
        `📁 mpy (${mpySize} KB)`,
        vscode.TreeItemCollapsibleState.Collapsed,
        'local-mpy',
        this.getWorkspacePath('mpy')
      );

      // Вузол src
      const srcItem = new FileItem(
        `📂 src (${srcSize} KB)`,
        vscode.TreeItemCollapsibleState.Expanded,
        'local-src',
        this.getWorkspacePath('src')
      );

      const rootNodes: FileItem[] = [mpyItem, srcItem];

      // Якщо вибрано порт, додаємо вузол пристрою:
      if ((global as any).MPY_LAST_PORT !== undefined) {
        const label = micropythonSysName
          ? `🔲 ${micropythonSysName}`
          : 'device (click to expand)';

        // Генеруємо унікальний id, щоб VSCode сприймав його як "новий" вузол і примусово згортав
        const deviceId = 'device-root-' + (global as any).MPY_LAST_PORT + '-' + Date.now();

        const deviceItem = new FileItem(
          label,
          vscode.TreeItemCollapsibleState.Collapsed,
          'device-root',
          '/'
        );
        deviceItem.id = deviceId;
        deviceItem.isLoaded = false;
        deviceItem.cachedChildren = undefined;

        rootNodes.push(deviceItem);
      }
      return rootNodes;
    }

    // Якщо отримуємо дітей для певного елемента
    switch (element.contextValue) {
      case 'local-mpy':
      case 'local-mpy-folder':
      case 'local-mpy-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('mpy');
        if (!safePath) {
          return [];
        }
        const children = await this.readLocalDirectory(safePath, 'local-mpy-file', false);
        element.isLoaded = true;
        element.cachedChildren = children;
        return children;
      }
      case 'local-src':
      case 'local-src-folder':
      case 'local-src-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('src');
        if (!safePath) {
          return [];
        }
        const children = await this.readLocalDirectory(safePath, 'local-src-file', true);
        element.isLoaded = true;
        element.cachedChildren = children;
        return children;
      }
      case 'device-root':
      case 'device-folder': {
        if (!element.isLoaded) {
          const children = await this.readDeviceDirectory(element.fullPath || '/', 'device-file');
          if (element.contextValue === 'device-root') {
            const refreshItem = new FileItem(
              '♻️ Refresh',
              vscode.TreeItemCollapsibleState.None,
              'refresh-device',
              element.fullPath
            );
            refreshItem.command = {
              command: 'mpytoolsFileExplorer.refreshDevice',
              title: 'Refresh device',
              arguments: [element]
            };
            children.unshift(refreshItem);
          }
          element.isLoaded = true;
          element.cachedChildren = children;
          return children;
        } else {
          return element.cachedChildren || [];
        }
      }
      default: {
        return [];
      }
    }
  }

  // Для локальних файлів: призначаємо resourceUri = vscode.Uri.file(...),
  // щоб відображалися іконки зі стандартної теми
  private async readLocalDirectory(
    dirPath: string,
    baseContextValue: string,
    expandFolders: boolean
  ): Promise<FileItem[]> {
    if (!fs.existsSync(dirPath)) {
      return [];
    }
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    const result: FileItem[] = [];

    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      const isDir = entry.isDirectory();

      let collapsible = vscode.TreeItemCollapsibleState.None;
      if (isDir) {
        collapsible = expandFolders
          ? vscode.TreeItemCollapsibleState.Expanded
          : vscode.TreeItemCollapsibleState.Collapsed;
      }

      let contextVal = baseContextValue;
      if (isDir) {
        contextVal += '-folder';
      }

      const label = entry.name;
      const fileItem = new FileItem(label, collapsible, contextVal, fullPath);

      // Застосувати іконки теми для локальних файлів/папок
      fileItem.resourceUri = vscode.Uri.file(fullPath);

      // Якщо це файл, додаємо команду для відкриття через вбудовану функцію VSCode
      if (!isDir) {
        fileItem.command = {
          command: 'vscode.open',
          title: 'Open File',
          arguments: [fileItem.resourceUri]
        };
      }

      result.push(fileItem);
    }
    return result;
  }

  // Для файлів на пристрої: зберігаємо реальний device-path в fullPath,
  // а окремо створюємо fakeLocalPath для resourceUri (щоб були іконки за розширенням)
  private async readDeviceDirectory(
    devicePath: string,
    baseContextValue: string
  ): Promise<FileItem[]> {
    const port = getSelectedPort();
    if (!port) {
      return [];
    }

    // Закриваємо MPY-термінали
    vscode.window.terminals
      .filter(t => t.name.startsWith('MPY'))
      .forEach(t => t.dispose());
    await new Promise(resolve => setTimeout(resolve, 300));

    // Активуємо логування для дій з папками
    mpyOutputChannel.show(true);

    const cmd = `mpremote connect ${port} fs ls ${devicePath}`;
    let rawLines: string[] = [];
    try {
      const output = await execPromise(cmd);
      rawLines = output.split('\n').map(l => l.trim()).filter(Boolean);
    } catch (err: any) {
      mpyOutputChannel.show(true);
      mpyOutputChannel.appendLine(`⚠️ Error updating folder ${devicePath}: ${err.message}`);
      return [];
    }

    const items: FileItem[] = [];
    for (let line of rawLines) {
      if (line.startsWith('ls :')) {
        continue;
      }
      const parts = line.split(/\s+/, 2);
      if (parts.length < 2) {
        continue;
      }
      let namePart = parts[1];
      let isDir = false;
      if (namePart.endsWith('/')) {
        isDir = true;
        namePart = namePart.replace(/\/+$/, '');
      }

      const collapsible = isDir
        ? vscode.TreeItemCollapsibleState.Collapsed
        : vscode.TreeItemCollapsibleState.None;
      const childContext = isDir ? 'device-folder' : baseContextValue;

      const childDevicePath = devicePath.endsWith('/')
        ? devicePath + namePart
        : devicePath + '/' + namePart;

      const fakeLocalPath = path.join('/MPY_DEVICE', childDevicePath);

      const label = namePart;
      const fileItem = new FileItem(label, collapsible, childContext, childDevicePath);

      fileItem.resourceUri = vscode.Uri.file(fakeLocalPath);

      fileItem.id = `device-item-${childDevicePath}-${Date.now()}`;

      if (childContext === 'device-file') {
        fileItem.command = {
          command: 'mpytools.openDeviceFile',
          title: 'Open File',
          arguments: [fileItem]
        };
      }

      items.push(fileItem);
    }

    mpyOutputChannel.show(true);
    mpyOutputChannel.appendLine(`✅ Updated device folder: ${devicePath}`);
    return items;
  }

  private getLocalFolderSize(relativePath: string): number {
    const dirPath = this.getWorkspacePath(relativePath);
    if (!dirPath || !fs.existsSync(dirPath)) {
      return 0;
    }
    let totalSize = 0;
    function recurse(folder: string) {
      const entries = fs.readdirSync(folder, { withFileTypes: true });
      for (const e of entries) {
        const full = path.join(folder, e.name);
        if (e.isDirectory()) {
          recurse(full);
        } else {
          totalSize += fs.statSync(full).size;
        }
      }
    }
    recurse(dirPath);
    return Math.floor(totalSize / 1024);
  }

  private getWorkspacePath(rel: string): string | undefined {
    const wsFolders = vscode.workspace.workspaceFolders;
    if (!wsFolders || wsFolders.length === 0) {
      return undefined;
    }
    return path.join(wsFolders[0].uri.fsPath, rel);
  }
}

class FileItem extends vscode.TreeItem {
  public isLoaded: boolean = false;
  public cachedChildren: FileItem[] | undefined;
  constructor(
    public readonly label: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly contextValue: string,
    /**
     * Зберігаємо тут **реальний** шлях на пристрої (або локальний),
     * який далі використовується для mpremote (для віддалених) або fs-операцій (для локальних)
     */
    public readonly fullPath?: string
  ) {
    super(label, collapsibleState);
  }
}

/** Виконати exec з Promise */
function execPromise(cmd: string): Promise<string> {
  return new Promise((resolve, reject) => {
    exec(cmd, (error, stdout, stderr) => {
      if (error) {
        mpyOutputChannel.appendLine(`❌ ${error.message}`);
        return reject(error);
      }
      if (stderr && stderr.trim()) {
        mpyOutputChannel.appendLine(`❌ ${stderr.trim()}`);
        return reject(new Error(stderr.trim()));
      }
      resolve(stdout);
    });
  });
}
