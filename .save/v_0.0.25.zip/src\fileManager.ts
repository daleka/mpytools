// fileManager.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';

import { mpyOutputChannel } from './extension';
import { micropythonSysName } from './extension';

// Допоміжна функція для канонізації шляху (нормалізація та приведення до нижнього регістру)
function getCanonicalPath(p: string): string {
  return path.normalize(p).toLowerCase();
}

// Глобальна мапа для збереження відповідності тимчасового файлу та реального device-шляху
const deviceFileMap: Map<string, string> = new Map<string, string>();

// Функція для отримання вибраного порту
function getSelectedPort(): string {
  return (global as any).MPY_LAST_PORT || 'auto';
}

// Функція реєстрації файлового менеджера
export function registerFileManager(context: vscode.ExtensionContext): void {
  const provider: FileManagerProvider = new FileManagerProvider();

  // Створення TreeView
  const treeView: vscode.TreeView<FileItem> = vscode.window.createTreeView('mpytoolsFileExplorer', {
    treeDataProvider: provider
  });
  context.subscriptions.push(treeView);

  // Реєстрація команди для глобального refresh (перемалювання дерева)
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refresh', () => {
      provider.refresh();
    })
  );

  // Реєстрація команди "Refresh folder"
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshFolder', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // Реєстрація команди "Refresh device"
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshDevice', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // Команда для відкриття MicroPython проекту
  vscode.commands.registerCommand('mpytools.openMicroPythonProject', async () => {
    const selected: vscode.Uri[] | undefined = await vscode.window.showOpenDialog({
      canSelectFiles: false,
      canSelectFolders: true,
      canSelectMany: false,
      openLabel: 'Open MicroPython Project'
    });
    if (selected && selected.length > 0) {
      vscode.commands.executeCommand('vscode.openFolder', selected[0]);
    }
  });

  // Команда для відкриття файлів з пристрою
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytools.openDeviceFile', async (item: FileItem) => {
      if (!item.fullPath) {
        return;
      }
      try {
        mpyOutputChannel.appendLine(`📥 Opening device file: ${item.fullPath}`);
        await openDeviceFile(item);
      } catch (err: any) {
        vscode.window.showErrorMessage(`Failed to open device file: ${err.message}`);
      }
    })
  );

  // Реєстрація команди "Save All Dirty" – зберігає всі відкриті незбережені документи
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytools.saveAllDirty', async () => {
      await vscode.workspace.saveAll();
      vscode.window.showInformationMessage('All files have been saved.');
    })
  );

  // Реєстрація команди "Open In Explorer" – відкриває поточну робочу директорію у зовнішньому файловому менеджері
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytools.openInExplorer', async () => {
      let targetUri: vscode.Uri | undefined;
      const activeEditor = vscode.window.activeTextEditor;
      if (activeEditor && activeEditor.document && activeEditor.document.uri) {
        // Отримуємо директорію активного файлу
        const filePath = activeEditor.document.uri.fsPath;
        const folderPath = path.dirname(filePath);
        targetUri = vscode.Uri.file(folderPath);
      } else if (vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders.length > 0) {
        // Фолбек: використання першої робочої директорії
        targetUri = vscode.workspace.workspaceFolders[0].uri;
      }
      if (targetUri) {
        await vscode.commands.executeCommand('revealFileInOS', targetUri);
      } else {
        vscode.window.showErrorMessage("No folder is open.");
      }
    })
  );

  // Обробка збереження файлів з пристрою – завантаження відбувається при кожному збереженні
  vscode.workspace.onDidSaveTextDocument(async (document: vscode.TextDocument) => {
    const localPath: string = getCanonicalPath(document.uri.fsPath);
    if (deviceFileMap.has(localPath)) {
      const devicePath: string = deviceFileMap.get(localPath)!;
      try {
        await uploadDeviceFile(localPath, devicePath);
        mpyOutputChannel.appendLine(`✅ Uploaded file to device: ${devicePath}`);
        // Не видаляємо запис, якщо файл залишається відкритим
      } catch (err: any) {
        vscode.window.showErrorMessage(`Failed to upload ${localPath} to device: ${err.message}`);
      }
    }
  });

  // Видалення запису з deviceFileMap при закритті документа (якщо файл більше не відкритий)
  vscode.workspace.onDidCloseTextDocument((document: vscode.TextDocument) => {
    const localPath: string = getCanonicalPath(document.uri.fsPath);
    if (deviceFileMap.has(localPath)) {
      deviceFileMap.delete(localPath);
      mpyOutputChannel.appendLine(`🔗 Mapping removed for closed file: ${localPath}`);
    }
  });

  // Оновлення контекстного ключа "mpytools.hasDirty" для кнопки "💾Save All"
  const updateDirtyContext = (): void => {
    const hasDirty: boolean = vscode.workspace.textDocuments.some(document => document.isDirty);
    vscode.commands.executeCommand('setContext', 'mpytools.hasDirty', hasDirty);
  };
  // Початкове оновлення контексту
  updateDirtyContext();
  // Підписка на події, що впливають на стан документів
  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument(updateDirtyContext),
    vscode.workspace.onDidSaveTextDocument(updateDirtyContext),
    vscode.workspace.onDidCloseTextDocument(updateDirtyContext)
  );

  // Видалено обробку події закриття документа для автоматичного завантаження,
  // щоб зберігати контроль над процесом завантаження при збереженні.
}

// Функція, яка відкриває файл з пристрою:
// 1. Завантажує файл з пристрою у тимчасову директорію за допомогою mpremote,
// 2. Відкриває файл у VSCode,
// 3. Зберігає відповідність локального тимчасового шляху та device-шляху для подальшого завантаження зміненого файлу.
async function openDeviceFile(fileItem: FileItem): Promise<void> {
  const devicePath: string = fileItem.fullPath!;
  const port: string = getSelectedPort();

  // Підготовка тимчасової директорії
  const temporaryDirectory: string = path.join(os.tmpdir(), 'mpytools_temp');
  if (!fs.existsSync(temporaryDirectory)) {
    fs.mkdirSync(temporaryDirectory, { recursive: true });
  }

  // Формування імені тимчасового файлу з збереженням оригінального розширення
  const baseName: string = path.basename(fileItem.label, path.extname(fileItem.label));
  const fileExtension: string = path.extname(fileItem.label);
  const temporaryFileName: string = `${baseName}-${Date.now()}${fileExtension}`;
  const temporaryFilePath: string = path.join(temporaryDirectory, temporaryFileName);

  mpyOutputChannel.appendLine(`⬇️ Downloading file from device: ${devicePath}`);
  // Завантаження файлу з пристрою у тимчасовий файл
  await downloadDeviceFile(devicePath, temporaryFilePath);

  // Відкриття тимчасового файлу у VSCode
  const document: vscode.TextDocument = await vscode.workspace.openTextDocument(temporaryFilePath);
  await vscode.window.showTextDocument(document, { preview: false });

  // Збереження відповідності для подальшого завантаження при збереженні
  const canonicalTemporaryPath: string = getCanonicalPath(temporaryFilePath);
  deviceFileMap.set(canonicalTemporaryPath, devicePath);
  mpyOutputChannel.appendLine(`🔗 Mapping set: ${canonicalTemporaryPath} -> ${devicePath}`);
}

// Допоміжна функція для завантаження файлу з пристрою
async function downloadDeviceFile(devicePath: string, localPath: string): Promise<void> {
  const port: string = getSelectedPort();
  const command: string = `mpremote connect ${port} fs cp :${devicePath} ${localPath}`;
  try {
    await execPromise(command);
    mpyOutputChannel.appendLine(`⬇️ Download complete: ${localPath}`);
  } catch (error: any) {
    throw error;
  }
}

// Допоміжна функція для завантаження файлу з локальної тимчасової директорії на пристрій
async function uploadDeviceFile(localPath: string, devicePath: string): Promise<void> {
  const port: string = getSelectedPort();
  const command: string = `mpremote connect ${port} fs cp -f ${localPath} :${devicePath}`;
  try {
    await execPromise(command);
    mpyOutputChannel.appendLine(`⬆️ Upload complete: ${localPath} to ${devicePath}`);
  } catch (error: any) {
    throw error;
  }
}

// Клас провайдера для дерева файлового менеджера
class FileManagerProvider implements vscode.TreeDataProvider<FileItem> {
  private _onDidChangeTreeData: vscode.EventEmitter<FileItem | undefined | void> =
    new vscode.EventEmitter<FileItem | undefined | void>();
  public readonly onDidChangeTreeData: vscode.Event<FileItem | undefined | void> =
    this._onDidChangeTreeData.event;

  public refresh(element?: FileItem): void {
    this._onDidChangeTreeData.fire(element);
  }

  public getTreeItem(element: FileItem): vscode.TreeItem {
    return element;
  }

  public async getChildren(element?: FileItem): Promise<FileItem[]> {
    // Якщо це кореневий вузол (без батьківського елемента)
    if (!element) {
      const sizeOfMpyFolder: number = this.getLocalFolderSize('mpy');
      const sizeOfSrcFolder: number = this.getLocalFolderSize('src');

      // Вузол "mpy"
      const mpyItem: FileItem = new FileItem(
        `📁 mpy (${sizeOfMpyFolder} KB)`,
        vscode.TreeItemCollapsibleState.Collapsed,
        'local-mpy',
        this.getWorkspacePath('mpy')
      );

      // Вузол "src"
      const srcItem: FileItem = new FileItem(
        `📂 src (${sizeOfSrcFolder} KB)`,
        vscode.TreeItemCollapsibleState.Expanded,
        'local-src',
        this.getWorkspacePath('src')
      );

      const rootNodes: FileItem[] = [mpyItem, srcItem];

      // Якщо вибрано порт, додаємо вузол пристрою
      if ((global as any).MPY_LAST_PORT !== undefined) {
        const label: string = micropythonSysName
          ? `🔲 ${micropythonSysName}`
          : 'device (click to expand)';

        // Генеруємо унікальний ідентифікатор, щоб VSCode сприймав його як "новий" вузол і примусово згортав
        const deviceIdentifier: string = 'device-root-' + (global as any).MPY_LAST_PORT + '-' + Date.now();

        const deviceItem: FileItem = new FileItem(
          label,
          vscode.TreeItemCollapsibleState.Collapsed,
          'device-root',
          '/'
        );
        deviceItem.id = deviceIdentifier;
        deviceItem.isLoaded = false;
        deviceItem.cachedChildren = undefined;

        rootNodes.push(deviceItem);
      }
      return rootNodes;
    }

    // Якщо отримуємо дітей для певного елемента
    switch (element.contextValue) {
      case 'local-mpy':
      case 'local-mpy-folder':
      case 'local-mpy-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('mpy');
        if (!safePath) {
          return [];
        }
        const children: FileItem[] = await this.readLocalDirectory(safePath, 'local-mpy-file', false);
        element.isLoaded = true;
        element.cachedChildren = children;
        return children;
      }
      case 'local-src':
      case 'local-src-folder':
      case 'local-src-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('src');
        if (!safePath) {
          return [];
        }
        const children: FileItem[] = await this.readLocalDirectory(safePath, 'local-src-file', true);
        element.isLoaded = true;
        element.cachedChildren = children;
        return children;
      }
      case 'device-root':
      case 'device-folder': {
        if (!element.isLoaded) {
          const children: FileItem[] = await this.readDeviceDirectory(element.fullPath || '/', 'device-file');
          if (element.contextValue === 'device-root') {
            const refreshItem: FileItem = new FileItem(
              '♻️ Refresh',
              vscode.TreeItemCollapsibleState.None,
              'refresh-device',
              element.fullPath
            );
            refreshItem.command = {
              command: 'mpytoolsFileExplorer.refreshDevice',
              title: 'Refresh device',
              arguments: [element]
            };
            children.unshift(refreshItem);
          }
          element.isLoaded = true;
          element.cachedChildren = children;
          return children;
        } else {
          return element.cachedChildren || [];
        }
      }
      default: {
        return [];
      }
    }
  }

  // Метод для читання локальної директорії та створення FileItem для кожного елемента
  private async readLocalDirectory(
    directoryPath: string,
    baseContextValue: string,
    shouldExpandFolders: boolean
  ): Promise<FileItem[]> {
    if (!fs.existsSync(directoryPath)) {
      return [];
    }
    const directoryEntries: fs.Dirent[] = fs.readdirSync(directoryPath, { withFileTypes: true });
    const result: FileItem[] = [];

    for (const entry of directoryEntries) {
      const fullPathOfEntry: string = path.join(directoryPath, entry.name);
      const isDirectory: boolean = entry.isDirectory();

      let collapsibleState: vscode.TreeItemCollapsibleState = vscode.TreeItemCollapsibleState.None;
      if (isDirectory) {
        collapsibleState = shouldExpandFolders
          ? vscode.TreeItemCollapsibleState.Expanded
          : vscode.TreeItemCollapsibleState.Collapsed;
      }

      let contextValueForEntry: string = baseContextValue;
      if (isDirectory) {
        contextValueForEntry += '-folder';
      }

      const labelForEntry: string = entry.name;
      const fileItem: FileItem = new FileItem(labelForEntry, collapsibleState, contextValueForEntry, fullPathOfEntry);

      // Призначення resourceUri для відображення іконок за стандартною темою
      fileItem.resourceUri = vscode.Uri.file(fullPathOfEntry);

      // Якщо це файл, додаємо команду для відкриття через вбудовану функцію VSCode
      if (!isDirectory) {
        fileItem.command = {
          command: 'vscode.open',
          title: 'Open File',
          arguments: [fileItem.resourceUri]
        };
      }

      result.push(fileItem);
    }
    return result;
  }

  // Метод для читання директорії на пристрої
  private async readDeviceDirectory(
    deviceDirectoryPath: string,
    baseContextValue: string
  ): Promise<FileItem[]> {
    const port: string = getSelectedPort();
    if (!port) {
      return [];
    }

    // Закриття MPY-терміналів
    const terminals: vscode.Terminal[] = vscode.window.terminals.filter(terminal => terminal.name.startsWith('MPY'));
    terminals.forEach(terminal => terminal.dispose());
    await new Promise(resolve => setTimeout(resolve, 300));

    // Активуємо логування для операцій з папками
    mpyOutputChannel.show(true);

    const commandForListing: string = `mpremote connect ${port} fs ls ${deviceDirectoryPath}`;
    let rawOutputLines: string[] = [];
    try {
      const commandOutput: string = await execPromise(commandForListing);
      rawOutputLines = commandOutput.split('\n').map(line => line.trim()).filter(line => line !== '');
    } catch (error: any) {
      mpyOutputChannel.show(true);
      mpyOutputChannel.appendLine(`⚠️ Error updating folder ${deviceDirectoryPath}: ${error.message}`);
      return [];
    }

    const items: FileItem[] = [];
    for (const line of rawOutputLines) {
      if (line.startsWith('ls :')) {
        continue;
      }
      const parts: string[] = line.split(/\s+/, 2);
      if (parts.length < 2) {
        continue;
      }
      let namePart: string = parts[1];
      let isDirectory: boolean = false;
      if (namePart.endsWith('/')) {
        isDirectory = true;
        namePart = namePart.replace(/\/+$/, '');
      }

      const collapsibleStateForChild: vscode.TreeItemCollapsibleState = isDirectory
        ? vscode.TreeItemCollapsibleState.Collapsed
        : vscode.TreeItemCollapsibleState.None;
      const contextValueForChild: string = isDirectory ? 'device-folder' : baseContextValue;

      const childDevicePath: string = deviceDirectoryPath.endsWith('/')
        ? deviceDirectoryPath + namePart
        : deviceDirectoryPath + '/' + namePart;

      // Формування фейкового локального шляху для resourceUri, щоб відображались іконки за розширенням
      const fakeLocalPath: string = path.join('/MPY_DEVICE', childDevicePath);

      const labelForChild: string = namePart;
      const fileItemForChild: FileItem = new FileItem(labelForChild, collapsibleStateForChild, contextValueForChild, childDevicePath);

      fileItemForChild.resourceUri = vscode.Uri.file(fakeLocalPath);

      fileItemForChild.id = `device-item-${childDevicePath}-${Date.now()}`;

      if (contextValueForChild === 'device-file') {
        fileItemForChild.command = {
          command: 'mpytools.openDeviceFile',
          title: 'Open File',
          arguments: [fileItemForChild]
        };
      }

      items.push(fileItemForChild);
    }

    mpyOutputChannel.show(true);
    mpyOutputChannel.appendLine(`✅ Updated device folder: ${deviceDirectoryPath}`);
    return items;
  }

  // Метод для отримання розміру локальної папки в кілобайтах
  private getLocalFolderSize(relativeFolderPath: string): number {
    const directoryPath: string | undefined = this.getWorkspacePath(relativeFolderPath);
    if (!directoryPath || !fs.existsSync(directoryPath)) {
      return 0;
    }
    let totalSizeInBytes: number = 0;
    function calculateSizeRecursively(folderPath: string): void {
      const folderEntries: fs.Dirent[] = fs.readdirSync(folderPath, { withFileTypes: true });
      for (const entry of folderEntries) {
        const fullEntryPath: string = path.join(folderPath, entry.name);
        if (entry.isDirectory()) {
          calculateSizeRecursively(fullEntryPath);
        } else {
          totalSizeInBytes += fs.statSync(fullEntryPath).size;
        }
      }
    }
    calculateSizeRecursively(directoryPath);
    return Math.floor(totalSizeInBytes / 1024);
  }

  // Метод для отримання абсолютного шляху робочої директорії для заданого відносного шляху
  private getWorkspacePath(relativePath: string): string | undefined {
    const workspaceFolders: readonly vscode.WorkspaceFolder[] | undefined = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
      return undefined;
    }
    return path.join(workspaceFolders[0].uri.fsPath, relativePath);
  }
}

// Клас, що представляє елемент дерева файлів
class FileItem extends vscode.TreeItem {
  public isLoaded: boolean = false;
  public cachedChildren: FileItem[] | undefined;
  public fullPath?: string;

  constructor(
    public readonly label: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly contextValue: string,
    fullPath?: string
  ) {
    super(label, collapsibleState);
    this.fullPath = fullPath;
  }
}

/** Виконання команди exec з використанням Promise */
function execPromise(command: string): Promise<string> {
  return new Promise((resolve, reject) => {
    exec(command, (error: Error | null, standardOutput: string, standardError: string) => {
      if (error) {
        mpyOutputChannel.appendLine(`❌ ${error.message}`);
        return reject(error);
      }
      if (standardError && standardError.trim()) {
        mpyOutputChannel.appendLine(`❌ ${standardError.trim()}`);
        return reject(new Error(standardError.trim()));
      }
      resolve(standardOutput);
    });
  });
}
