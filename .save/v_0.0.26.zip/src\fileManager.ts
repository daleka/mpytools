import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';

import { mpyOutputChannel } from './extension';
import { micropythonSysName } from './extension';

// Функція канонізації шляху (нормалізація та приведення до нижнього регістру)
function getCanonicalPath(p: string): string {
  return path.normalize(p).toLowerCase();
}

// Нормалізація пристроєвого шляху – забезпечуємо, що шлях починається з "/"
function normalizeDevicePath(p: string): string {
  let normalized = p;
  if (!normalized.startsWith('/')) {
    normalized = '/' + normalized;
  }
  return normalized.replace(/\\/g, '/');
}

/**
 * Формує віддалений шлях для mpremote (без початкового слешу після двокрапки).
 * Якщо пристрій є Pyboard (micropythonSysName містить "pyboard"),
 * і шлях починається з "/flash/", він прибирається.
 */
function getRemoteFilePath(p: string): string {
  const normalized = normalizeDevicePath(p);
  if (micropythonSysName && micropythonSysName.toLowerCase().includes("pyboard")) {
    if (normalized.startsWith('/flash/')) {
      return ':' + normalized.substring(7);
    }
  }
  return ':' + normalized.substring(1);
}

// Глобальна мапа для збереження відповідності тимчасового файлу та реального device-шляху
const deviceFileMap: Map<string, string> = new Map<string, string>();

// Функція для отримання вибраного порту
function getSelectedPort(): string {
  return (global as any).MPY_LAST_PORT || 'auto';
}

export function registerFileManager(context: vscode.ExtensionContext): void {
  const provider: FileManagerProvider = new FileManagerProvider();

  // Створення TreeView
  const treeView: vscode.TreeView<FileItem> = vscode.window.createTreeView('mpytoolsFileExplorer', {
    treeDataProvider: provider
  });
  context.subscriptions.push(treeView);

  // Глобальний refresh дерева
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refresh', () => {
      provider.refresh();
    })
  );

  // "Refresh folder"
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshFolder', (item: FileItem) => {
      mpyOutputChannel.appendLine(`♻️ RefreshFolder invoked for: ${item.label}`);
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // "Refresh device"
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.refreshDevice', (item: FileItem) => {
      item.isLoaded = false;
      item.cachedChildren = undefined;
      provider.refresh(item);
    })
  );

  // Відкрити проект
  vscode.commands.registerCommand('mpytools.openMicroPythonProject', async () => {
    const selected: vscode.Uri[] | undefined = await vscode.window.showOpenDialog({
      canSelectFiles: false,
      canSelectFolders: true,
      canSelectMany: false,
      openLabel: 'Open MicroPython Project'
    });
    if (selected && selected.length > 0) {
      vscode.commands.executeCommand('vscode.openFolder', selected[0]);
    }
  });

  // Відкрити файл з пристрою
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytools.openDeviceFile', async (item: FileItem) => {
      if (!item.fullPath) { return; }
      try {
        mpyOutputChannel.appendLine(`📥 Opening device file: ${item.fullPath}`);
        await openDeviceFile(item);
      } catch (err: any) {
        vscode.window.showErrorMessage(`Failed to open device file: ${err.message}`);
      }
    })
  );

  // Save All Dirty
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytools.saveAllDirty', async () => {
      await vscode.workspace.saveAll();
      vscode.window.showInformationMessage('All files have been saved.');
    })
  );

  // Open In Explorer
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytools.openInExplorer', async () => {
      let targetUri: vscode.Uri | undefined;
      const activeEditor = vscode.window.activeTextEditor;
      if (activeEditor && activeEditor.document && activeEditor.document.uri) {
        const filePath = activeEditor.document.uri.fsPath;
        const folderPath = path.dirname(filePath);
        targetUri = vscode.Uri.file(folderPath);
      } else if (vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders.length > 0) {
        targetUri = vscode.workspace.workspaceFolders[0].uri;
      }
      if (targetUri) {
        await vscode.commands.executeCommand('revealFileInOS', targetUri);
      } else {
        vscode.window.showErrorMessage("No folder is open.");
      }
    })
  );

  // Завантаження файлів з пристрою при збереженні
  vscode.workspace.onDidSaveTextDocument(async (document: vscode.TextDocument) => {
    const localPath: string = getCanonicalPath(document.uri.fsPath);
    if (deviceFileMap.has(localPath)) {
      const devicePath: string = deviceFileMap.get(localPath)!;
      try {
        await uploadDeviceFile(localPath, devicePath);
        mpyOutputChannel.appendLine(`✅ Uploaded file to device: ${devicePath}`);
      } catch (err: any) {
        vscode.window.showErrorMessage(`Failed to upload ${localPath} to device: ${err.message}`);
      }
    }
  });

  // Видалення мапування при закритті документа
  vscode.workspace.onDidCloseTextDocument((document: vscode.TextDocument) => {
    const localPath: string = getCanonicalPath(document.uri.fsPath);
    if (deviceFileMap.has(localPath)) {
      deviceFileMap.delete(localPath);
      mpyOutputChannel.appendLine(`🔗 Mapping removed for closed file: ${localPath}`);
    }
  });

  const updateDirtyContext = (): void => {
    const hasDirty: boolean = vscode.workspace.textDocuments.some(document => document.isDirty);
    vscode.commands.executeCommand('setContext', 'mpytools.hasDirty', hasDirty);
  };
  updateDirtyContext();
  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument(() => { updateDirtyContext(); }),
    vscode.workspace.onDidSaveTextDocument(() => { updateDirtyContext(); }),
    vscode.workspace.onDidCloseTextDocument(() => { updateDirtyContext(); })
  );

  // ===== ДОДАТКОВІ КОМАНДИ ДЛЯ ПРИСТРОЄВИХ ФАЙЛІВ =====

  // Команда "Створити файл" всередині пристроєвої папки
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.createDeviceFile', async (item: FileItem) => {
      const fileName = await vscode.window.showInputBox({ prompt: 'Enter new file name' });
      if (!fileName) { return; }
      const basePath = item.fullPath ? normalizeDevicePath(item.fullPath) : '/';
      const newFilePath = path.join(basePath, fileName).replace(/\\/g, '/');
      const port = getSelectedPort();
      const command = `mpremote connect ${port} fs touch ${getRemoteFilePath(newFilePath)}`;
      try {
        await execPromise(command);
        mpyOutputChannel.appendLine(`✅ Created file: ${newFilePath}`);
        provider.refresh(item);
      } catch (error: any) {
        vscode.window.showErrorMessage(`Failed to create file: ${error.message}`);
      }
    })
  );

  // Команда "Створити папку" всередині пристроєвої папки
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.createDeviceFolder', async (item: FileItem) => {
      const folderName = await vscode.window.showInputBox({ prompt: 'Enter new folder name' });
      if (!folderName) { return; }
      const basePath = item.fullPath ? normalizeDevicePath(item.fullPath) : '/';
      const newFolderPath = path.join(basePath, folderName).replace(/\\/g, '/');
      const port = getSelectedPort();
      const command = `mpremote connect ${port} fs mkdir ${getRemoteFilePath(newFolderPath)}`;
      try {
        await execPromise(command);
        mpyOutputChannel.appendLine(`✅ Created folder: ${newFolderPath}`);
        provider.refresh(item);
      } catch (error: any) {
        vscode.window.showErrorMessage(`Failed to create folder: ${error.message}`);
      }
    })
  );

  // 1. Перейменувати файл
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.renameDeviceFile', async (item: FileItem) => {
      const currentName = path.basename(item.fullPath || '');
      const newName = await vscode.window.showInputBox({ prompt: 'Enter new file name', value: currentName });
      if (!newName) { return; }
      const parentPath = item.fullPath ? path.dirname(normalizeDevicePath(item.fullPath)) : '/';
      const newPath = path.join(parentPath, newName).replace(/\\/g, '/');
      const port = getSelectedPort();
      const copyCommand = `mpremote connect ${port} fs cp ${getRemoteFilePath(item.fullPath!)} ${getRemoteFilePath(newPath)}`;
      const removeCommand = `mpremote connect ${port} fs rm ${getRemoteFilePath(item.fullPath!)}`;
      try {
        await execPromise(copyCommand);
        mpyOutputChannel.appendLine(`✅ Copied file to: ${newPath}`);
        await execPromise(removeCommand);
        mpyOutputChannel.appendLine(`✅ Removed old file: ${item.fullPath}`);
        provider.refresh();
      } catch (error: any) {
        vscode.window.showErrorMessage(`Failed to rename device file: ${error.message}`);
      }
    })
  );

  // 2. Видалити файл
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.deleteDeviceFile', async (item: FileItem) => {
      const confirm = await vscode.window.showWarningMessage(
        `Are you sure you want to delete file "${item.fullPath}"?`,
        { modal: true },
        'Yes'
      );
      if (confirm !== 'Yes') { return; }
      const port = getSelectedPort();
      const command = `mpremote connect ${port} fs rm ${getRemoteFilePath(item.fullPath!)}`;
      try {
        await execPromise(command);
        mpyOutputChannel.appendLine(`✅ Deleted device file: ${item.fullPath}`);
        provider.refresh();
      } catch (error: any) {
        vscode.window.showErrorMessage(`Failed to delete device file: ${error.message}`);
      }
    })
  );

  // 3. Відправити файл у локальний проєкт
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.sendDeviceFileToLocal', async (item: FileItem) => {
      if (!item.fullPath) { return; }
      const workspaceFolders = vscode.workspace.workspaceFolders;
      if (!workspaceFolders || workspaceFolders.length === 0) {
        vscode.window.showErrorMessage("No workspace folder is open.");
        return;
      }
      const workspaceRoot = workspaceFolders[0].uri.fsPath;
      const relativeDevicePath = item.fullPath.replace(/^\//, '');
      const destPath = path.join(workspaceRoot, 'src', relativeDevicePath);
      const destDir = path.dirname(destPath);
      if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
      }
      if (fs.existsSync(destPath)) {
        const confirm = await vscode.window.showWarningMessage(
          `File ${destPath} already exists. Replace?`,
          { modal: true },
          'Yes'
        );
        if (confirm !== 'Yes') {
          return;
        }
      }
      const port = getSelectedPort();
      const command = `mpremote connect ${port} fs cp ${getRemoteFilePath(item.fullPath)} ${destPath}`;
      try {
        await execPromise(command);
        mpyOutputChannel.appendLine(`✅ Sent device file to local project: ${destPath}`);
      } catch (error: any) {
        vscode.window.showErrorMessage(`Failed to send device file to local project: ${error.message}`);
      }
    })
  );

  // 4. Видалити папку (для пристроєвої папки) – рекурсивне видалення
  context.subscriptions.push(
    vscode.commands.registerCommand('mpytoolsFileExplorer.deleteDeviceFolder', async (item: FileItem) => {
      const confirm = await vscode.window.showWarningMessage(
        `Are you sure you want to delete folder "${item.fullPath}" and all its contents?`,
        { modal: true },
        'Yes'
      );
      if (confirm !== 'Yes') { return; }
      try {
        await deleteDeviceFolderRecursively(item.fullPath!);
        mpyOutputChannel.appendLine(`✅ Deleted device folder: ${item.fullPath}`);
        provider.refresh();
      } catch (error: any) {
        vscode.window.showErrorMessage(`Failed to delete device folder: ${error.message}`);
      }
    })
  );
} // Кінець registerFileManager

// Функція відкриття файлу з пристрою
async function openDeviceFile(fileItem: FileItem): Promise<void> {
  const devicePath: string = fileItem.fullPath!;
  const port: string = getSelectedPort();

  const temporaryDirectory: string = path.join(os.tmpdir(), 'mpytools_temp');
  if (!fs.existsSync(temporaryDirectory)) {
    fs.mkdirSync(temporaryDirectory, { recursive: true });
  }

  const baseName: string = path.basename(fileItem.label, path.extname(fileItem.label));
  const fileExtension: string = path.extname(fileItem.label);
  const temporaryFileName: string = `${baseName}-${Date.now()}${fileExtension}`;
  const temporaryFilePath: string = path.join(temporaryDirectory, temporaryFileName);

  mpyOutputChannel.appendLine(`⬇️ Downloading file from device: ${devicePath}`);
  await downloadDeviceFile(devicePath, temporaryFilePath);

  const document: vscode.TextDocument = await vscode.workspace.openTextDocument(temporaryFilePath);
  await vscode.window.showTextDocument(document, { preview: false });

  const canonicalTemporaryPath: string = getCanonicalPath(temporaryFilePath);
  deviceFileMap.set(canonicalTemporaryPath, devicePath);
  mpyOutputChannel.appendLine(`🔗 Mapping set: ${canonicalTemporaryPath} -> ${devicePath}`);
}

async function downloadDeviceFile(devicePath: string, localPath: string): Promise<void> {
  const port: string = getSelectedPort();
  const command: string = `mpremote connect ${port} fs cp :${devicePath} ${localPath}`;
  try {
    await execPromise(command);
    mpyOutputChannel.appendLine(`⬇️ Download complete: ${localPath}`);
  } catch (error: any) {
    throw error;
  }
}

async function uploadDeviceFile(localPath: string, devicePath: string): Promise<void> {
  const port: string = getSelectedPort();
  const command: string = `mpremote connect ${port} fs cp -f ${localPath} :${devicePath}`;
  try {
    await execPromise(command);
    mpyOutputChannel.appendLine(`⬆️ Upload complete: ${localPath} to ${devicePath}`);
  } catch (error: any) {
    throw error;
  }
}

// Рекурсивне видалення папки на пристрої
async function deleteDeviceFolderRecursively(folderPath: string): Promise<void> {
  const port = getSelectedPort();
  const listCommand = `mpremote connect ${port} fs ls ${getRemoteFilePath(folderPath)}`;
  let output: string;
  try {
    output = await execPromise(listCommand);
  } catch (err: any) {
    throw new Error(`Failed to list folder contents: ${err.message}`);
  }
  const lines = output.split('\n').map(line => line.trim()).filter(line => line !== '' && !line.startsWith('ls :'));
  for (const line of lines) {
    const parts = line.split(/\s+/, 2);
    if (parts.length < 2) {
      continue;
    }
    let entryName = parts[1];
    const isDir = entryName.endsWith('/');
    if (isDir) {
      entryName = entryName.replace(/\/+$/, '');
    }
    const childPath = folderPath.endsWith('/') ? folderPath + entryName : folderPath + '/' + entryName;
    if (isDir) {
      await deleteDeviceFolderRecursively(childPath);
    } else {
      const rmFileCmd = `mpremote connect ${port} fs rm ${getRemoteFilePath(childPath)}`;
      await execPromise(rmFileCmd);
    }
  }
  const rmdirCmd = `mpremote connect ${port} fs rmdir ${getRemoteFilePath(folderPath)}`;
  await execPromise(rmdirCmd);
}

class FileManagerProvider implements vscode.TreeDataProvider<FileItem> {
  private _onDidChangeTreeData: vscode.EventEmitter<FileItem | undefined | void> =
    new vscode.EventEmitter<FileItem | undefined | void>();
  public readonly onDidChangeTreeData: vscode.Event<FileItem | undefined | void> =
    this._onDidChangeTreeData.event;

  public refresh(element?: FileItem): void {
    this._onDidChangeTreeData.fire(element);
  }

  public getTreeItem(element: FileItem): vscode.TreeItem {
    return element;
  }

  public async getChildren(element?: FileItem): Promise<FileItem[]> {
    if (!element) {
      const sizeOfMpyFolder: number = this.getLocalFolderSize('mpy');
      const sizeOfSrcFolder: number = this.getLocalFolderSize('src');

      const mpyItem: FileItem = new FileItem(
        `📁 mpy (${sizeOfMpyFolder} KB)`,
        vscode.TreeItemCollapsibleState.Collapsed,
        'local-mpy',
        this.getWorkspacePath('mpy')
      );

      const srcItem: FileItem = new FileItem(
        `📂 src (${sizeOfSrcFolder} KB)`,
        vscode.TreeItemCollapsibleState.Expanded,
        'local-src',
        this.getWorkspacePath('src')
      );

      const rootNodes: FileItem[] = [mpyItem, srcItem];

      if ((global as any).MPY_LAST_PORT !== undefined) {
        const label: string = micropythonSysName
          ? `🔲 ${micropythonSysName}`
          : 'device (click to expand)';

        const deviceIdentifier: string = 'device-root-' + (global as any).MPY_LAST_PORT + '-' + Date.now();

        const deviceItem: FileItem = new FileItem(
          label,
          vscode.TreeItemCollapsibleState.Collapsed,
          'device-root',
          '/'
        );
        deviceItem.id = deviceIdentifier;
        deviceItem.isLoaded = false;
        deviceItem.cachedChildren = undefined;

        rootNodes.push(deviceItem);
      }
      return rootNodes;
    }

    switch (element.contextValue) {
      case 'local-mpy':
      case 'local-mpy-folder':
      case 'local-mpy-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('mpy');
        if (!safePath) {
          return [];
        }
        const children: FileItem[] = await this.readLocalDirectory(safePath, 'local-mpy-file', false);
        element.isLoaded = true;
        element.cachedChildren = children;
        return children;
      }
      case 'local-src':
      case 'local-src-folder':
      case 'local-src-file-folder': {
        const safePath = element.fullPath ?? this.getWorkspacePath('src');
        if (!safePath) {
          return [];
        }
        const children: FileItem[] = await this.readLocalDirectory(safePath, 'local-src-file', true);
        element.isLoaded = true;
        element.cachedChildren = children;
        return children;
      }
      case 'device-root':
      case 'device-folder': {
        if (!element.isLoaded) {
          const children: FileItem[] = await this.readDeviceDirectory(element.fullPath || '/', 'device-file');
          if (element.contextValue === 'device-root') {
            const refreshItem: FileItem = new FileItem(
              '♻️ Refresh',
              vscode.TreeItemCollapsibleState.None,
              'refresh-device',
              element.fullPath
            );
            refreshItem.command = {
              command: 'mpytoolsFileExplorer.refreshDevice',
              title: 'Refresh device',
              arguments: [element]
            };
            children.unshift(refreshItem);
          }
          element.isLoaded = true;
          element.cachedChildren = children;
          return children;
        } else {
          return element.cachedChildren || [];
        }
      }
      default: {
        return [];
      }
    }
  }

  private async readLocalDirectory(
    directoryPath: string,
    baseContextValue: string,
    shouldExpandFolders: boolean
  ): Promise<FileItem[]> {
    if (!fs.existsSync(directoryPath)) {
      return [];
    }
    const directoryEntries: fs.Dirent[] = fs.readdirSync(directoryPath, { withFileTypes: true });
    const result: FileItem[] = [];
    for (const entry of directoryEntries) {
      const fullPathOfEntry: string = path.join(directoryPath, entry.name);
      const isDirectory: boolean = entry.isDirectory();
      let collapsibleState: vscode.TreeItemCollapsibleState = vscode.TreeItemCollapsibleState.None;
      if (isDirectory) {
        collapsibleState = shouldExpandFolders
          ? vscode.TreeItemCollapsibleState.Expanded
          : vscode.TreeItemCollapsibleState.Collapsed;
      }
      let contextValueForEntry: string = baseContextValue;
      if (isDirectory) {
        contextValueForEntry += '-folder';
      }
      const labelForEntry: string = entry.name;
      const fileItem: FileItem = new FileItem(labelForEntry, collapsibleState, contextValueForEntry, fullPathOfEntry);
      fileItem.resourceUri = vscode.Uri.file(fullPathOfEntry);
      if (!isDirectory) {
        fileItem.command = {
          command: 'vscode.open',
          title: 'Open File',
          arguments: [fileItem.resourceUri]
        };
      }
      result.push(fileItem);
    }
    return result;
  }

  private async readDeviceDirectory(
    deviceDirectoryPath: string,
    baseContextValue: string
  ): Promise<FileItem[]> {
    const port: string = getSelectedPort();
    if (!port) {
      return [];
    }
    const terminals: vscode.Terminal[] = vscode.window.terminals.filter(terminal => terminal.name.startsWith('MPY'));
    terminals.forEach(terminal => terminal.dispose());
    await new Promise(resolve => setTimeout(resolve, 300));
    mpyOutputChannel.show(true);
    const commandForListing: string = `mpremote connect ${port} fs ls ${deviceDirectoryPath}`;
    let rawOutputLines: string[] = [];
    try {
      const commandOutput: string = await execPromise(commandForListing);
      rawOutputLines = commandOutput.split('\n').map(line => line.trim()).filter(line => line !== '');
    } catch (error: any) {
      mpyOutputChannel.show(true);
      mpyOutputChannel.appendLine(`⚠️ Error updating folder ${deviceDirectoryPath}: ${error.message}`);
      return [];
    }
    const items: FileItem[] = [];
    for (const line of rawOutputLines) {
      if (line.startsWith('ls :')) {
        continue;
      }
      const parts: string[] = line.split(/\s+/, 2);
      if (parts.length < 2) {
        continue;
      }
      // Отримуємо оригінальне ім'я без emoji
      let rawName: string = parts[1];
      let isDirectory: boolean = false;
      if (rawName.endsWith('/')) {
        isDirectory = true;
        rawName = rawName.replace(/\/+$/, '');
      }
      // Формуємо displayName з емодзі для папок
      let displayName = rawName;
      if (isDirectory) {
        displayName = '📁 ' + rawName;
      }
      const collapsibleStateForChild: vscode.TreeItemCollapsibleState = isDirectory
        ? vscode.TreeItemCollapsibleState.Collapsed
        : vscode.TreeItemCollapsibleState.None;
      const contextValueForChild: string = isDirectory ? 'device-folder' : baseContextValue;
      const childDevicePath: string = deviceDirectoryPath.endsWith('/')
        ? deviceDirectoryPath + rawName
        : deviceDirectoryPath + '/' + rawName;
      const fakeLocalPath: string = path.join('/MPY_DEVICE', childDevicePath);
      const fileItemForChild: FileItem = new FileItem(displayName, collapsibleStateForChild, contextValueForChild, childDevicePath);
      fileItemForChild.resourceUri = vscode.Uri.file(fakeLocalPath);
      fileItemForChild.id = `device-item-${childDevicePath}-${Date.now()}`;
      if (contextValueForChild === 'device-file') {
        fileItemForChild.command = {
          command: 'mpytools.openDeviceFile',
          title: 'Open File',
          arguments: [fileItemForChild]
        };
      }
      items.push(fileItemForChild);
    }
    mpyOutputChannel.show(true);
    mpyOutputChannel.appendLine(`✅ Updated device folder: ${deviceDirectoryPath}`);
    return items;
  }

  private getLocalFolderSize(relativeFolderPath: string): number {
    const directoryPath: string | undefined = this.getWorkspacePath(relativeFolderPath);
    if (!directoryPath || !fs.existsSync(directoryPath)) {
      return 0;
    }
    let totalSizeInBytes: number = 0;
    function calculateSizeRecursively(folderPath: string): void {
      const folderEntries: fs.Dirent[] = fs.readdirSync(folderPath, { withFileTypes: true });
      for (const entry of folderEntries) {
        const fullEntryPath: string = path.join(folderPath, entry.name);
        if (entry.isDirectory()) {
          calculateSizeRecursively(fullEntryPath);
        } else {
          totalSizeInBytes += fs.statSync(fullEntryPath).size;
        }
      }
    }
    calculateSizeRecursively(directoryPath);
    return Math.floor(totalSizeInBytes / 1024);
  }

  private getWorkspacePath(relativePath: string): string | undefined {
    const workspaceFolders: readonly vscode.WorkspaceFolder[] | undefined = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
      return undefined;
    }
    return path.join(workspaceFolders[0].uri.fsPath, relativePath);
  }
}

class FileItem extends vscode.TreeItem {
  public isLoaded: boolean = false;
  public cachedChildren: FileItem[] | undefined;
  public fullPath?: string;

  constructor(
    public readonly label: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly contextValue: string,
    fullPath?: string
  ) {
    super(label, collapsibleState);
    this.fullPath = fullPath;
  }
}

function execPromise(command: string): Promise<string> {
  return new Promise((resolve, reject) => {
    exec(command, (error: Error | null, standardOutput: string, standardError: string) => {
      if (error) {
        mpyOutputChannel.appendLine(`❌ ${error.message}`);
        return reject(error);
      }
      if (standardError && standardError.trim()) {
        mpyOutputChannel.appendLine(`❌ ${standardError.trim()}`);
        return reject(new Error(standardError.trim()));
      }
      resolve(standardOutput);
    });
  });
}
