// compileAndRun.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';

/**
 * Функція реєструє кнопку та команду "mpytools.compileAndRun".
 * Уся логіка (запит оптимізації, компіляція, копіювання, запуск main) перенесена сюди з extension.ts
 *
 * @param context               - контекст розширення (для registerCommand, subscriptions тощо)
 * @param outputChannel         - канад виводу (наприклад, mpyOutputChannel)
 * @param execPromise           - функція для виконання shell-команд (з extension.ts)
 * @param getLastUsedPort       - функція «гетер» для lastUsedPort
 * @param getSelectedMethod     - функція «гетер» для selectedCompilationMethod
 * @param setSelectedMethod     - функція «сетер» для selectedCompilationMethod
 * @param needsRecompile        - функція перевірки потреби перекомпіляції
 * @param compilePyFile         - функція компіляції одного .py у .mpy
 * @param findPyFiles           - функція пошуку .py в папці src
 * @param openTerminalAndRunMain - функція запуску main (mpremote connect ... + repl)
 * @param formatPort            - функція форматування порту (COM3 -> COM3 / /dev/... -> /dev/...)
 *
 * @returns {vscode.StatusBarItem} Повертаємо StatusBarItem, щоб у extension.ts можна було його .show()/.hide().
 */
export function registerCompileAndRunCommand(
  context: vscode.ExtensionContext,
  outputChannel: vscode.OutputChannel,
  execPromise: (cmd: string) => Promise<string>,
  getLastUsedPort: () => string,
  getSelectedMethod: () => string | undefined,
  setSelectedMethod: (val: string | undefined) => void,
  needsRecompile: (pyFilePath: string, srcPath: string, mpyPath: string) => boolean,
  compilePyFile: (
    pyFilePath: string,
    srcPath: string,
    mpyPath: string
  ) => Promise<string>,
  findPyFiles: (rootDir: string, ignoreList?: string[]) => string[],
  openTerminalAndRunMain: (port: string, debugTerminal: vscode.Terminal) => void,
  formatPort: (port: string) => string
): vscode.StatusBarItem {

  // 1) Створюємо кнопку (StatusBarItem) для "Compile & Run"
  let compileStatusBarItem = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Left,
    -1
  );
  compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
  compileStatusBarItem.tooltip = 'Натисніть, щоб скомпілювати та запустити проект';
  compileStatusBarItem.color = 'lightblue';
  compileStatusBarItem.command = 'mpytools.compileAndRun';

  // Ховаємо її за замовчуванням (відобразимо після успішного вибору порту)
  compileStatusBarItem.hide();
  context.subscriptions.push(compileStatusBarItem);

  // 2) Реєструємо команду "mpytools.compileAndRun"
  let disposableCompileAndRun = vscode.commands.registerCommand('mpytools.compileAndRun', async () => {
    let workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
      vscode.window.showErrorMessage('Не знайдено відкритий Workspace. (No workspace folder opened)');
      return;
    }

    // Якщо ще не вибраний рівень оптимізації - питаємо
    let currentMethod = getSelectedMethod();
    if (!currentMethod) {
      const compilationOptions: vscode.QuickPickItem[] = [
        { label: 'mpy-cross optimization Level 0', description: 'Без оптимізації / No optimization' },
        { label: 'mpy-cross optimization Level 1', description: 'Базова оптимізація / Basic optimization' },
        { label: 'mpy-cross optimization Level 2', description: 'Середня оптимізація / Medium optimization' },
        { label: 'mpy-cross optimization Level 3', description: 'Максимальна оптимізація / Max optimization' }
      ];
      const result = await vscode.window.showQuickPick(compilationOptions, {
        placeHolder: 'Оберіть метод компіляції / Choose mpy-cross optimization level',
        canPickMany: false
      });
      if (!result) {
        vscode.window.showWarningMessage('Компіляцію скасовано / Compilation canceled: no method selected.');
        return;
      }
      const match = result.label.match(/Level (\d+)/);
      const chosen = match ? match[1] : '0';
      setSelectedMethod(chosen); // зберігаємо вибраний рівень
      currentMethod = chosen;
    }

    const workspaceRoot = workspaceFolders[0].uri.fsPath;
    const srcPath = path.join(workspaceRoot, 'src');
    const mpyPath = path.join(workspaceRoot, 'mpy');

    // Закриваємо існуючі MPY-термінали
    vscode.window.terminals.forEach((t) => {
      if (t.name.startsWith('MPY')) {
        t.dispose();
      }
    });

    // Невелика пауза
    await new Promise(resolve => setTimeout(resolve, 300));

    // Лог у Output Channel
    outputChannel.show(false);
    outputChannel.appendLine("🔹 Starting Compile & Run process...");
    outputChannel.appendLine(`   - Selected optimization level: O${currentMethod}`);

    vscode.window.withProgress({
      location: vscode.ProgressLocation.Notification,
      title: 'MPyTools: Compile & Run',
      cancellable: false
    }, async (progress) => {
      try {
        // Крок 1: Перевірка/створення папки mpy
        progress.report({ message: 'Preparing compilation...' });
        outputChannel.appendLine("🔹 Preparing compilation...");

        if (!fs.existsSync(mpyPath)) {
          fs.mkdirSync(mpyPath);
          vscode.window.showInformationMessage(`Created directory (Створено теку): ${mpyPath}`);
          outputChannel.appendLine(`   ✅ Created directory: ${mpyPath}`);
        }

        // Знаходимо .py файли
        let pyFiles = findPyFiles(srcPath, []);
        outputChannel.appendLine(`   🔹 Found ${pyFiles.length} .py files in "src"`);
        progress.report({ message: `Found ${pyFiles.length} .py files...` });

        // Показуємо анімацію на кнопці
        compileStatusBarItem.color = 'red';
        compileStatusBarItem.text = '$(sync~spin) MPY: Please wait...';

        let compiledCount = 0;
        for (let i = 0; i < pyFiles.length; i++) {
          const pyFile = pyFiles[i];
          const shortName = path.relative(workspaceRoot, pyFile);

          if (needsRecompile(pyFile, srcPath, mpyPath)) {
            progress.report({ message: `Compiling: ${shortName}` });
            outputChannel.appendLine(`   🔹 Compiling: ${shortName}`);

            try {
              await compilePyFile(pyFile, srcPath, mpyPath);
              compiledCount++;
              outputChannel.appendLine(`      ✅ OK: ${shortName}`);
            } catch (err: any) {
              vscode.window.showWarningMessage(`Compilation error (Помилка компіляції): ${shortName}\n${err}`);
              outputChannel.appendLine(`      ❌ Compilation error: ${shortName} -> ${err.message}`);
            }
          } else {
            outputChannel.appendLine(`   🔹 Skipped (unchanged): ${shortName}`);
          }
        }

        outputChannel.appendLine(`   ✅ Compiled ${compiledCount} / ${pyFiles.length} py-files`);
        vscode.window.showInformationMessage(`Compiled (скомпільовано) ${compiledCount} out of (із) ${pyFiles.length}.`);

        // Копіюємо .mpy файли на пристрій
        let copyPath = mpyPath;
        if (os.platform() === 'win32') {
          copyPath += '\\.';
        } else {
          copyPath += '/.';
        }
        progress.report({ message: 'Copying files to device...' });
        outputChannel.appendLine("🔹 Copying compiled files to device...");

        const usedPort = getLastUsedPort();
        const finalPort = (usedPort === 'auto')
          ? 'auto'
          : formatPort(usedPort);

        const copyCmd = (finalPort === 'auto')
          ? `mpremote connect auto fs cp -r "${copyPath}" ":/"`
          : `mpremote connect ${finalPort} fs cp -r "${copyPath}" ":/"`;

        try {
          await execPromise(copyCmd);
          vscode.window.showInformationMessage('Copy complete (Копіювання завершено).');
          outputChannel.appendLine("   ✅ Copy complete.");
        } catch (err: any) {
          vscode.window.showErrorMessage(`Error copying files (Помилка копіювання): ${err}`);
          outputChannel.appendLine(`   ❌ Error copying files: ${err.message}`);
          compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
          compileStatusBarItem.color = 'lightblue';
          return;
        }

        // Відновлюємо кнопку
        compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
        compileStatusBarItem.color = 'lightblue';

        // Запускаємо main
        await new Promise(resolve => setTimeout(resolve, 500));
        let debugTerminal = vscode.window.createTerminal('MPY Debugging');
        debugTerminal.show();

        vscode.window.showInformationMessage('Launching main (Запуск main)...');
        outputChannel.appendLine("🔹 Launching main...");

        openTerminalAndRunMain(finalPort, debugTerminal);

        progress.report({ message: 'Done.' });
        outputChannel.appendLine("✅ Compile & Run completed.\n");
      } catch (error: any) {
        vscode.window.showErrorMessage(`Compile & Run failed (Сталася помилка): ${error}`);
        outputChannel.appendLine(`❌ Compile & Run failed: ${error.message}`);
      }
    });
  });

  context.subscriptions.push(disposableCompileAndRun);

  // Повертаємо StatusBarItem, щоб extension.ts міг його .show()/.hide()
  return compileStatusBarItem;
}
