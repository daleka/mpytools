// compileAndRun.ts

import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';

/**
 * Функція реєструє кнопку та команду "mpytools.compileAndRun".
 * Уся логіка (запит оптимізації, компіляція, копіювання, запуск main) перенесена сюди з extension.ts.
 *
 * @param context               - контекст розширення
 * @param outputChannel         - канал виводу
 * @param execPromise           - функція для виконання shell-команд
 * @param getLastUsedPort       - функція-гетер для lastUsedPort
 * @param getSelectedMethod     - функція-гетер для selectedCompilationMethod
 * @param setSelectedMethod     - функція-сетер для selectedCompilationMethod
 * @param needsRecompile        - функція перевірки потреби перекомпіляції
 * @param compilePyFile         - функція компіляції одного .py у .mpy
 * @param findPyFiles           - функція пошуку .py в папці src
 * @param openTerminalAndRunMain - функція запуску main (mpremote connect ... + repl)
 * @param formatPort            - функція форматування порту
 * @param getMicropythonVersion - функція-гетер для micropythonVersion
 * @param getMicropythonBytecodeVersion - функція-гетер для micropythonBytecodeVersion
 * @param getMicropythonArchitecture - функція-гетер для micropythonArchitecture
 * @param getMicropythonMsmallIntBits - функція-гетер для micropythonMsmallIntBits
 *
 * @returns {vscode.StatusBarItem} Статус-бар елемент.
 */
export function registerCompileAndRunCommand(
  context: vscode.ExtensionContext,
  outputChannel: vscode.OutputChannel,
  execPromise: (cmd: string) => Promise<string>,
  getLastUsedPort: () => string,
  getSelectedMethod: () => string | undefined,
  setSelectedMethod: (val: string | undefined) => void,
  needsRecompile: (pyFilePath: string, srcPath: string, mpyPath: string) => boolean,
  compilePyFile: (
    pyFilePath: string,
    srcPath: string,
    mpyPath: string
  ) => Promise<string>,
  findPyFiles: (rootDir: string, ignoreList?: string[]) => string[],
  openTerminalAndRunMain: (port: string, debugTerminal: vscode.Terminal) => void,
  formatPort: (port: string) => string,
  getMicropythonVersion: () => string | undefined,
  getMicropythonBytecodeVersion: () => number | undefined,
  getMicropythonArchitecture: () => string | undefined,
  getMicropythonMsmallIntBits: () => number | undefined
): vscode.StatusBarItem {
  // 1) Створюємо кнопку для "Compile & Run"
  let compileStatusBarItem = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Left,
    -1
  );
  compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
  compileStatusBarItem.tooltip = 'Click to compile and run the project';
  compileStatusBarItem.color = 'lightblue';
  compileStatusBarItem.command = 'mpytools.compileAndRun';

  compileStatusBarItem.hide();
  context.subscriptions.push(compileStatusBarItem);

  // 2) Реєструємо команду "mpytools.compileAndRun"
  let disposableCompileAndRun = vscode.commands.registerCommand('mpytools.compileAndRun', async () => {
    let workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
      vscode.window.showErrorMessage('No workspace folder opened.');
      return;
    }

    let currentMethod = getSelectedMethod();
    if (!currentMethod) {
      const compilationOptions: vscode.QuickPickItem[] = [
        { label: 'mpy-cross optimization Level 0', description: 'No optimization' },
        { label: 'mpy-cross optimization Level 1', description: 'Basic optimization' },
        { label: 'mpy-cross optimization Level 2', description: 'Medium optimization' },
        { label: 'mpy-cross optimization Level 3', description: 'Max optimization' }
      ];
      const result = await vscode.window.showQuickPick(compilationOptions, {
        placeHolder: 'Choose mpy-cross optimization level',
        canPickMany: false
      });
      if (!result) {
        vscode.window.showWarningMessage('Compilation canceled: no method selected.');
        return;
      }
      const match = result.label.match(/Level (\d+)/);
      const chosen = match ? match[1] : '0';
      setSelectedMethod(chosen);
      currentMethod = chosen;
    }

    const workspaceRoot = workspaceFolders[0].uri.fsPath;
    const srcPath = path.join(workspaceRoot, 'src');
    const mpyPath = path.join(workspaceRoot, 'mpy');

    vscode.window.terminals.forEach((t) => {
      if (t.name.startsWith('MPY')) {
        t.dispose();
      }
    });

    await new Promise(resolve => setTimeout(resolve, 300));

    outputChannel.show(false);
    outputChannel.appendLine("🔹 Starting Compile & Run...");
    outputChannel.appendLine(`   - Selected optimization level: O${currentMethod}`);

    // Отримуємо актуальні значення через гетери
    const archFlag = getMicropythonArchitecture() ? `-march=${getMicropythonArchitecture()}` : '(no arch)';
    const smallIntFlag = getMicropythonMsmallIntBits() ? `-msmall-int-bits=${getMicropythonMsmallIntBits()}` : '(no small-int-bits)';
    const versionFlag = getMicropythonBytecodeVersion() !== undefined ? `-b ${getMicropythonBytecodeVersion()}` : `-c 1.20`;
    outputChannel.appendLine(`   - mpy-cross ${archFlag} ${smallIntFlag} -O${currentMethod} ${versionFlag} <path_to_file> -o <output_path>`);
    outputChannel.appendLine(""); // порожній рядок для розділення

    vscode.window.withProgress({
      location: vscode.ProgressLocation.Notification,
      title: 'MPyTools: Compile & Run',
      cancellable: false
    }, async (progress) => {
      try {
        progress.report({ message: 'Preparing compilation...' });
        outputChannel.appendLine("🔹 Preparing compilation...");

        if (!fs.existsSync(mpyPath)) {
          fs.mkdirSync(mpyPath);
          vscode.window.showInformationMessage(`Created directory: ${mpyPath}`);
          outputChannel.appendLine(`   ✅ Created directory: ${mpyPath}`);
          outputChannel.appendLine("");
        }

        let pyFiles = findPyFiles(srcPath, []);
        outputChannel.appendLine(`   🔹 Found ${pyFiles.length} .py files in "src"`);
        progress.report({ message: `Found ${pyFiles.length} .py files...` });
        outputChannel.appendLine("");

        compileStatusBarItem.color = 'red';
        compileStatusBarItem.text = '$(sync~spin) MPY: Please wait...';

        let compiledCount = 0;
        for (let i = 0; i < pyFiles.length; i++) {
          const pyFile = pyFiles[i];
          const shortName = path.relative(workspaceRoot, pyFile);

          if (needsRecompile(pyFile, srcPath, mpyPath)) {
            progress.report({ message: `Compiling: ${shortName}` });
            outputChannel.appendLine(`   🔹 Compiling: ${shortName}`);

            try {
              await compilePyFile(pyFile, srcPath, mpyPath);
              compiledCount++;
              outputChannel.appendLine(`      ✅ OK: ${shortName}`);
            } catch (err: any) {
              vscode.window.showWarningMessage(`Compilation error: ${shortName}\n${err}`);
              outputChannel.appendLine(`      ❌ Compilation error: ${shortName} -> ${err.message}`);
            }
          } else {
            outputChannel.appendLine(`   🔹 Skipped (unchanged): ${shortName}`);
          }
          outputChannel.appendLine(""); // порожній рядок для розділення між файлами
        }

        outputChannel.appendLine(`   ✅ Compiled ${compiledCount} / ${pyFiles.length} .py files`);
        vscode.window.showInformationMessage(`Compiled ${compiledCount} out of ${pyFiles.length}.`);
        outputChannel.appendLine("");

        let copyPath = mpyPath;
        if (os.platform() === 'win32') {
          copyPath += '\\.';
        } else {
          copyPath += '/.';
        }
        progress.report({ message: 'Copying files to device...' });
        outputChannel.appendLine("🔹 Copying compiled files to device...");
        outputChannel.appendLine("");

        const usedPort = getLastUsedPort();
        const finalPort = (usedPort === 'auto')
          ? 'auto'
          : formatPort(usedPort);

        const copyCmd = (finalPort === 'auto')
          ? `mpremote connect auto fs cp -r "${copyPath}" ":/"`
          : `mpremote connect ${finalPort} fs cp -r "${copyPath}" ":/"`;

        try {
          await execPromise(copyCmd);
          vscode.window.showInformationMessage('Copy complete.');
          outputChannel.appendLine("   ✅ Copy complete.");
          outputChannel.appendLine("");
        } catch (err: any) {
          vscode.window.showErrorMessage(`Error copying files: ${err}`);
          outputChannel.appendLine(`   ❌ Error copying files: ${err.message}`);
          compileStatusBarItem.text = '$(tools) MPY: Compile & Run';
          compileStatusBarItem.color = 'lightblue';
          return;
        }

        function getFolderSize(dirPath: string): number {
          let totalSize = 0;
          const files = fs.readdirSync(dirPath);
          files.forEach((file) => {
            const fullPath = path.join(dirPath, file);
            const stats = fs.statSync(fullPath);
            if (stats.isDirectory()) {
              totalSize += getFolderSize(fullPath);
            } else {
              totalSize += stats.size;
            }
          });
          return totalSize;
        }

        const folderSizeBytes = getFolderSize(mpyPath);
        const folderSizeKB = folderSizeBytes / 1024;
        outputChannel.appendLine(`🔹 Total size of 'mpy' folder: ${folderSizeKB.toFixed(2)} KB`);
        outputChannel.appendLine("");

        outputChannel.appendLine("🔹 Launching main...");
        outputChannel.appendLine("");

        let debugTerminal = vscode.window.createTerminal('MPY Debugging');
        debugTerminal.show();

        // Затримка 2 секунди перед перемиканням на термінал, щоб користувач встиг ознайомитись з логом
        await new Promise(resolve => setTimeout(resolve, 2000));

        openTerminalAndRunMain(finalPort, debugTerminal);

        progress.report({ message: 'Done.' });
        outputChannel.appendLine("✅ Compile & Run completed.\n");
      } catch (error: any) {
        vscode.window.showErrorMessage(`Compile & Run failed: ${error}`);
        outputChannel.appendLine(`❌ Compile & Run failed: ${error.message}`);
      }
    });
  });

  context.subscriptions.push(disposableCompileAndRun);
  return compileStatusBarItem;
}
